/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.Date;
import java.util.List;

/**
 *
 * @author hp
 */
public class Consultation extends Rdv {
    private Medecin medecin ;
     private Ordonnance ordonnance ;
   
     private final String TYPE = "TYPE_CONSULTATION";

    public Medecin getMedecin() {
        return medecin;
    }

    public void setMedecin(Medecin medecin) {
        this.medecin = medecin;
    }


    public Ordonnance getOrdonnance() {
        return ordonnance;
    }

    public void setOrdonnance(Ordonnance ordonnance) {
        this.ordonnance = ordonnance;
    }
    public Consultation() {
        this.type = TYPE;
    }

    public Consultation(Medecin medecin, Ordonnance ordonnance, Date date, String type, Boolean unarchived) {
        super(date, type, unarchived);
        this.medecin = medecin;
        
        this.ordonnance = ordonnance;
      
    }

    public Consultation(Medecin medecin, Ordonnance ordonnance, int id, Date date, String type, Boolean unarchived, Patient patient) {
        super(id, date, type, unarchived, patient);
        this.medecin = medecin;
        this.ordonnance = ordonnance;
        
    }

    public Consultation(Medecin medecin, Ordonnance ordonnance, int id, Date date, String type, Boolean unarchived) {
        super(id, date, type, unarchived);
        this.medecin = medecin;
        this.ordonnance = ordonnance;
       
    }

    public Consultation(Medecin medecin, Ordonnance ordonnance, Date date, String type, Boolean unarchived, Patient patient) {
        super(date, type, unarchived, patient);
        this.medecin = medecin;
        this.ordonnance = ordonnance;
        
    }

    @Override
   public String toString(){
       if(this.medecin!=null){
         return "M : "+this.medecin.nomComplet;
       }
       return"";
   }

   

   
    
}
