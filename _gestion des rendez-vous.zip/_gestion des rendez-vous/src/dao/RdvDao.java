/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Consultation;
import entities.Ordonnance;
import entities.Patient;
import entities.Prestation;
import entities.Rdv;
import entities.ResponsablePrestation;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hp
 */
public class RdvDao implements IDao<Rdv>{
    private final String  SQL_BY_ID = "SELECT * FROM `rdv` WHERE id = ?";
     private final String  SQL_ALL = "SELECT * FROM `rdv`";
     private final String  SQL_ALL_ID_MEDECIN = "SELECT * FROM `rdv` WHERE medecin_id=? and date=?";
      private final String  SQL_ALL_ID_MEDECIN1 = "SELECT * FROM `rdv` WHERE medecin_id=?";
      private final String  SQL_ALL_ID_PATIENT = "SELECT * FROM `rdv` WHERE patient_id=?";
     private final String SQL_INSERT = "INSERT INTO `rdv` "
            + " ( `type` , `date` , `unarchived` ,`patient_id` ,`libellep`) "
            + " VALUES (?,?,?,?,?)";
      private final String SQL_UPDATE="UPDATE `rdv` SET `unarchived`=? WHERE `id`= ?";
     private final String SQL_UPDATE1="UPDATE `rdv` SET `medecin_id`=? WHERE `id`= ?";
     private final String SQL_UPDATE2="UPDATE `rdv` SET `responsable_id`=? WHERE `id`= ?";
    private final DataBase dataBase= new DataBase();
    PatientDao pat = new PatientDao();
    OrdonnanceDao ordo = new OrdonnanceDao();
    ResponsablePrestationDao resp = new ResponsablePrestationDao();
    @Override
    public int insert(Rdv rdv) {
            int id = 0;
            try {
                dataBase.openConnexion();
                dataBase.initPrepareStatement(SQL_INSERT);
                dataBase.getPs().setString(1, rdv.getType() );
                dataBase.getPs().setDate(2, (Date) rdv.getDate());
                dataBase.getPs().setBoolean(3, rdv.getUnarchived() );
                dataBase.getPs().setString(5,rdv.getLibellep());
                dataBase.getPs().setInt(4, rdv.getPatient().getId() );
                dataBase.executeUpdate(SQL_INSERT);
                ResultSet rs = dataBase.getPs().getGeneratedKeys();
                if(rs.next())
                {
                    id = rs.getInt(1);   
                }
            } catch (SQLException ex) {
                Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
                dataBase.closeConnexion();   
            }
            return id;
    }

    @Override
    public int update(Rdv rdv) {
         int nbrLigne=0;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_UPDATE);
        try {
            dataBase.getPs().setBoolean(1,rdv.getUnarchived());
            dataBase.getPs().setInt(2, rdv.getId());
            nbrLigne=dataBase.executeUpdate(SQL_UPDATE);         
        } catch (SQLException ex) {
            Logger.getLogger(PrestationDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        dataBase.closeConnexion();
        return nbrLigne;
    }
    public int updateToConsultation(Rdv rdv,int id) {
         int nbrLigne=0;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_UPDATE1);
        try {
            dataBase.getPs().setInt(1,id);
            dataBase.getPs().setInt(2, rdv.getId());
            nbrLigne=dataBase.executeUpdate(SQL_UPDATE1);         
        } catch (SQLException ex) {
            Logger.getLogger(PrestationDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        dataBase.closeConnexion();
        return nbrLigne;
    }
    public int updateToPrestation(Rdv rdv,int id) {
         int nbrLigne=0;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_UPDATE2);
        try {
            dataBase.getPs().setInt(1,id);
            dataBase.getPs().setInt(2, rdv.getId());
            nbrLigne=dataBase.executeUpdate(SQL_UPDATE2);         
        } catch (SQLException ex) {
            Logger.getLogger(PrestationDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        dataBase.closeConnexion();
        return nbrLigne;
    }
    public int updateToRdv(Rdv rdv) {
         int nbrLigne=0;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_UPDATE2);
        try {
            dataBase.getPs().setInt(1,0);
            dataBase.getPs().setInt(2, rdv.getId());
            nbrLigne=dataBase.executeUpdate(SQL_UPDATE2);         
        } catch (SQLException ex) {
            Logger.getLogger(PrestationDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        dataBase.closeConnexion();
        return nbrLigne;
    }


    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Rdv> findAll() {
        List<Rdv> rdvs=new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL);
       
           
        
        try {
             ResultSet rs =dataBase.executeSelect(SQL_ALL);
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    Patient patient = pat.findById(rs.getInt("patient_id"));
                   if(rs.getInt("medecin_id")==0 && rs.getInt("responsable_id")==0){
                    Rdv rd =new Rdv();
                    rd.setType(rs.getString("type"));
                     rd.setId(rs.getInt("id"));
                     rd.setDate(rs.getDate("date"));
                     rd.setUnarchived(rs.getBoolean("unarchived"));
                     rd.setLibellep(rs.getString("libellep"));
                     rd.setPatient(patient);
                    rdvs.add(rd);
                   }
                } catch (SQLException ex) {
                    Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return rdvs;
    }
     public List<Rdv> findAl(int id) {
        List<Rdv> rdvs=new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_ID_PATIENT);
       
        
        try {
            dataBase.getPs().setInt(1, id);
            ResultSet rs =dataBase.executeSelect(SQL_ALL_ID_PATIENT);
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    Patient patient = pat.findById(rs.getInt("patient_id"));
                    if(rs.getInt("medecin_id")==0 && rs.getInt("responsable_id")==0){
                    Rdv rd =new Rdv();
                     rd.setType(rs.getString("type"));
                     rd.setLibellep(rs.getString("libellep"));
                     rd.setId(rs.getInt("id"));
                     rd.setDate(rs.getDate("date"));
                     rd.setUnarchived(rs.getBoolean("unarchived"));
                     rd.setPatient(patient);
                    rdvs.add(rd);
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return rdvs;
    }
    public List<Rdv> findAllById_Medecin(Date date , int id) throws SQLException {
        List<Rdv> rdvs=new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_ID_MEDECIN);
       dataBase.getPs().setDate(1,date);
       dataBase.getPs().setInt(2, id);
            ResultSet rs =dataBase.executeSelect(SQL_ALL_ID_MEDECIN);
        
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    Patient patient = pat.findById(rs.getInt("patient_id"));
                    Rdv rd =new Rdv();
                     rd.setId(rs.getInt("id"));
                     rd.setDate(rs.getDate("date"));
                     rd.setUnarchived(rs.getBoolean("unarchived"));
                     rd.setPatient(patient);
                    rdvs.add(rd);
                } catch (SQLException ex) {
                    Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return rdvs;
    }
     public List<Patient> findAllByIdMedecin(int id) throws SQLException {
        List<Patient> patients=new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_ID_MEDECIN1);
       dataBase.getPs().setInt(1, id);
            ResultSet rs =dataBase.executeSelect(SQL_ALL_ID_MEDECIN1);
        
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    Patient patient = pat.findById(rs.getInt("patient_id"));
                    if(patients.isEmpty()){
                        patients.add(patient);
                    }else{
                        for (Patient pati : patients){
                            if(!pati.getCode().equals(patient.getCode())){
                                patients.add(patient);
                            }
                        }
                    }       
                } catch (SQLException ex) {
                    Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return patients;
    }
    public List<Rdv> findAllById_Patient( int id) throws SQLException {
        List<Rdv> rdvs=new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_ID_PATIENT);
       dataBase.getPs().setInt(1,id);
            ResultSet rs =dataBase.executeSelect(SQL_ALL_ID_PATIENT);
        
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    Patient patient = pat.findById(rs.getInt("patient_id"));
                    Rdv rd =new Rdv();
                     rd.setId(rs.getInt("id"));
                     rd.setDate(rs.getDate("date"));
                     rd.setUnarchived(rs.getBoolean("unarchived"));
                     rd.setPatient(patient);
                    rdvs.add(rd);
                } catch (SQLException ex) {
                    Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return rdvs;
    }
     public List findAllBy(int id) throws SQLException {
        List files=new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_ID_PATIENT);
       dataBase.getPs().setInt(1,id);
            ResultSet rs =dataBase.executeSelect(SQL_ALL_ID_PATIENT);
        
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    Patient patient = pat.findById(rs.getInt("patient_id"));
                    if("TYPE_CONSULTATION".equals(rs.getString("type"))){
                    Consultation rd = new Consultation();
                     rd.setId(rs.getInt("id"));
                     rd.setDate(rs.getDate("date"));
                     rd.setUnarchived(rs.getBoolean("unarchived"));
                     rd.setPatient(patient);
                     Ordonnance ordonnance = ordo.findById(rs.getInt("ordonnance_id"));
                     rd.setOrdonnance(ordonnance);
                     rd.setLibellep(rs.getString("libellep"));
                      files.add(rd);
                    }else{
                     Prestation rd = new Prestation();
                     rd.setId(rs.getInt("id"));
                     rd.setDate(rs.getDate("date"));
                     rd.setUnarchived(rs.getBoolean("unarchived"));
                     rd.setPatient(patient);
                     ResponsablePrestation responsable = resp.findById(rs.getInt("responsable_id"));
                     rd.setResponsable(responsable);
                     rd.setLibellep(rs.getString("libellep"));
                     files.add(rd);
                    }
                   
                } catch (SQLException ex) {
                    Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return files;
    }

    @Override
    public Rdv findById(int id) {
        Rdv rdv=null;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_BY_ID);
        try {
            dataBase.getPs().setInt(1, id);
        } catch (SQLException ex) {
            Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
        }
            ResultSet rs =dataBase.executeSelect(SQL_BY_ID);
        
            try {
                //Mapping relation vers objet
                if(rs.next()){
                 Patient patient = pat.findById(rs.getInt("patient_id"));
                 rdv =new Rdv();
                     rdv.setId(rs.getInt("id"));
                     rdv.setDate(rs.getDate("date"));
                     rdv.setUnarchived(rs.getBoolean("unarchived"));
                     rdv.setPatient(patient);
                }
            } catch (SQLException ex) {
                Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        dataBase.closeConnexion();
        return rdv;
    }
    
}
