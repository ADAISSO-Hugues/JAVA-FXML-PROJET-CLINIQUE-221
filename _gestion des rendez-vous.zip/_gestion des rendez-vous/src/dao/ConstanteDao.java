/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Constante;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hp
 */
public class ConstanteDao implements IDao<Constante> {
   private final DataBase dataBase = new DataBase();
    private final String SQL_INSERT = "INSERT INTO `constante` "
            + " ( `libellec`) "
            + " VALUES ( ?)";
    private final String SQL_ALL=" SELECT * FROM `constante`";
    private final String SQL_BY_ID="SELECT * FROM `constante` WHERE id=?";
    @Override
    public int insert(Constante constante) {
         int id = 0;
        try {
            dataBase.openConnexion();
            dataBase.initPrepareStatement(SQL_INSERT);
            dataBase.getPs().setString(1, constante.getLibellec() );
            dataBase.executeUpdate(SQL_INSERT);
            ResultSet rs = dataBase.getPs().getGeneratedKeys();
            if(rs.next())
            {
                id = rs.getInt(1);   
            }
        } catch (SQLException ex) {
            Logger.getLogger(ConstanteDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            dataBase.closeConnexion();   
        }
        return id;
    }

    @Override
    public int update(Constante ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Constante> findAll() {
          List<Constante> constante=new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL);
       
            ResultSet rs =dataBase.executeSelect(SQL_ALL);
        
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    Constante cons =new Constante(rs.getInt("id"),rs.getString("libellec"));
                    constante.add(cons);
                } catch (SQLException ex) {
                    Logger.getLogger(ConstanteDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(ConstanteDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return constante;
    }
    @Override
    public Constante findById(int id) {
        Constante constante=null;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_BY_ID);
            try {
                dataBase.getPs().setInt(1, id);
            ResultSet rs =dataBase.executeSelect(SQL_BY_ID);
                //Mapping relation vers objet
                if(rs.next()){
                constante=new Constante(rs.getInt("id"),rs.getString("libellec"));
                }
            } catch (SQLException ex) {
                Logger.getLogger(AntecedentDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        dataBase.closeConnexion();
        return constante;
    }
    
}
