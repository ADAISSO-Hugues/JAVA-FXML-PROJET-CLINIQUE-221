/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.ConCons;
import entities.Historique;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hp
 */
public class HistoriqueDao implements IDao<Historique> {
private DataBase dataBase = new DataBase();
    private final String SQL_INSERT = "INSERT INTO `historique` "
            + " ( `patient_id`,`antecedent_id`) "
            + " VALUES (?,?)";
    private final String SQL_ALL=" SELECT * FROM `historique`";
    private final String SQL_BY_ID="SELECT * FROM `historique` WHERE patient_id=?";
    @Override
    public int insert(Historique histo) {
        int id = 0;
            try {
                dataBase.openConnexion();
                dataBase.initPrepareStatement(SQL_INSERT);
                dataBase.getPs().setInt(1, histo.getId_patient() );
                dataBase.getPs().setInt(2, histo.getId_antecedent());
                dataBase.executeUpdate(SQL_INSERT);
                ResultSet rs = dataBase.getPs().getGeneratedKeys();
                if(rs.next())
                {
                    id = rs.getInt(1);   
                }
            } catch (SQLException ex) {
                Logger.getLogger(HistoriqueDao.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
                dataBase.closeConnexion();   
            }
            return id;
    }   

    @Override
    public int update(Historique ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Historique> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Historique findById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<Historique> findAllBy(int id) throws SQLException {
        List<Historique> historiques= new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_BY_ID);
       
         
        try {
            dataBase.getPs().setInt(1, id);
            ResultSet rs =dataBase.executeSelect(SQL_BY_ID);
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    Historique histo=new Historique(rs.getInt("antecedent_id"),rs.getInt("patient_id"));
                    historiques.add(histo);
                } catch (SQLException ex) {
                    Logger.getLogger(HistoriqueDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(HistoriqueDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return historiques;
          
    }
    
}
