/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Constante;
import entities.Consultation;
import entities.Medecin;
import entities.Ordonnance;
import entities.Patient;
import entities.Prestation;
import entities.Rdv;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hp
 */
public class ConsultationDao implements IDao<Consultation>{
 private final String SQL_INSERT = "INSERT INTO `rdv` "
            + " ( `type` , `date` ,` unarchived` , `patient_id` , `medecin_id`,`ordonnance_id`) "
            + " VALUES ('TYPE_CONSULTATION',?,?,?,?,?)";
    private final String SQL_ALL=" SELECT * FROM `rdv`";
    private final String SQL_ALL_ID_MEDECIN=" SELECT * FROM `rdv` WHERE medecin_id=?";
     private final String SQL_ALL_ID_PATIENT=" SELECT * FROM `rdv` WHERE patient_id=?";
     private final String SQL_BY_ID="SELECT * FROM `rdv` WHERE type like 'TYPE_CONSULTATION' and id=?";
     private final String SQL_UPDATE="UPDATE `rdv` SET `unarchived`=? WHERE `id`= ?";
      private final String SQL_UPDATE1="UPDATE `rdv` SET `medecin_id`=? WHERE `id`= ?";
     
    private final DataBase dataBase = new DataBase();
    private  final MedecinDao med= new MedecinDao();
    private final PatientDao pat = new PatientDao();
    private final  OrdonnanceDao ord = new OrdonnanceDao();
    
    @Override
    public int insert(Consultation consultation) {
         int id = 0;
        try {
            dataBase.openConnexion();
            dataBase.initPrepareStatement(SQL_INSERT);
            dataBase.getPs().setDate(1, (Date) consultation.getDate());
            dataBase.getPs().setBoolean(2, consultation.getUnarchived());
            dataBase.getPs().setInt(3, consultation.getPatient().getId());
            dataBase.getPs().setInt(4, consultation.getMedecin().getId());
            dataBase.getPs().setInt(5, consultation.getOrdonnance().getId());
            
            
            dataBase.executeUpdate(SQL_INSERT);
            ResultSet rs =dataBase.getPs().getGeneratedKeys();
            if(rs.next())
            {
                id = rs.getInt(1);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ConsultationDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            dataBase.closeConnexion();   
        } 
        return id;
    }

    @Override
    public int update(Consultation consultation) {
        int nbrLigne=0;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_UPDATE);
        try {
            dataBase.getPs().setBoolean(1, consultation.getUnarchived());
            dataBase.getPs().setInt(2, consultation.getId());
            nbrLigne=dataBase.executeUpdate(SQL_UPDATE);         
        } catch (SQLException ex) {
            Logger.getLogger(ConsultationDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        dataBase.closeConnexion();
        return nbrLigne;
    }
 public int updateToRdv(Consultation cons) {
         int nbrLigne=0;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_UPDATE1);
        try {
            dataBase.getPs().setInt(1,0);
            dataBase.getPs().setInt(2, cons.getId());
            nbrLigne=dataBase.executeUpdate(SQL_UPDATE1);         
        } catch (SQLException ex) {
            Logger.getLogger(ConsultationDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        dataBase.closeConnexion();
        return nbrLigne;
    }
    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Consultation> findAll() {
        List<Consultation> consultations = new ArrayList(); 
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL);
        try {
            ResultSet rs = dataBase.executeSelect(SQL_ALL);
            
            while(rs.next())
            {
                Consultation pt = new Consultation();
                pt.setId(rs.getInt("id"));
                pt.setDate(rs.getDate("date"));
                pt.setUnarchived(rs.getBoolean("unarchived"));
                Medecin medecin = med.findById(rs.getInt("medecin_id"));
                Patient patient = pat.findById(rs.getInt("patient_id"));
                Ordonnance ordonnance = ord.findById(rs.getInt("ordonnance_id"));
                pt.setMedecin(medecin);
                pt.setPatient(patient);
               pt.setOrdonnance(ordonnance);
                
               
              consultations.add(pt);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ConsultationDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        
        return consultations;
    }
public List<Consultation> findAllById_Medecin(int id) throws SQLException {
        List<Consultation> consultations = new ArrayList(); 
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_ID_MEDECIN);
        dataBase.getPs().setInt(1, id);
        try {
            ResultSet rs = dataBase.executeSelect(SQL_ALL_ID_MEDECIN);
            
            while(rs.next())
            {
                Consultation pt = new Consultation();
                pt.setId(rs.getInt("id"));
                pt.setDate(rs.getDate("date"));
                pt.setUnarchived(rs.getBoolean("unarchived"));
                Medecin medecin = med.findById(rs.getInt("medecin_id"));
                Patient patient = pat.findById(rs.getInt("patient_id"));
                Ordonnance ordonnance = ord.findById(rs.getInt("ordonnance_id"));
                pt.setMedecin(medecin);
                pt.setPatient(patient);
                pt.setOrdonnance(ordonnance);
              consultations.add(pt);
            }
           
        } catch (SQLException ex) {
            Logger.getLogger(ConsultationDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        
        return consultations;
    }
public List<Consultation> findAllById_Patient(int id) throws SQLException {
        List<Consultation> consultations = new ArrayList(); 
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_ID_PATIENT);
        dataBase.getPs().setInt(1, id);
        try {
            ResultSet rs = dataBase.executeSelect(SQL_ALL_ID_PATIENT);
            
            while(rs.next())
            {
                if(rs.getInt("medecin_id")!=0){
                Consultation pt = new Consultation();
                pt.setId(rs.getInt("id"));
                pt.setDate(rs.getDate("date"));
                pt.setUnarchived(rs.getBoolean("unarchived"));
                Patient patient =pat.findById(rs.getInt("patient_id"));
                Medecin medecin = med.findById(rs.getInt("medecin_id"));
                Ordonnance ordonnance = ord.findById(rs.getInt("ordonnance_id"));
                pt.setMedecin(medecin);
                pt.setPatient(patient);
                pt.setOrdonnance(ordonnance);
              consultations.add(pt);
                }
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ConsultationDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return consultations;
    }
    @Override
    public Consultation findById(int id) {
        Consultation pt=null;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_BY_ID);
        
        
            try {
            dataBase.getPs().setInt(1, id);
            ResultSet rs =dataBase.executeSelect(SQL_BY_ID);
            pt = new Consultation();
            if(rs.next()){
                pt.setId(rs.getInt("id"));
                pt.setDate(rs.getDate("date"));
                pt.setUnarchived(rs.getBoolean("unarchived"));
                Medecin medecin = med.findById(rs.getInt("medecin_id"));
                Patient patient = pat.findById(rs.getInt("patient_id"));
                Ordonnance ordonnance = ord.findById(rs.getInt("ordonnance_id"));
                pt.setMedecin(medecin);
                pt.setPatient(patient);
                pt.setOrdonnance(ordonnance);
                
            } 
            } catch (SQLException ex) {
                Logger.getLogger(ConsultationDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        dataBase.closeConnexion();
        return pt;
    }
    
}
