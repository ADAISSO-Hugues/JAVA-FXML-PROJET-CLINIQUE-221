/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views.Medecin;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcons;
import entities.Consultation;
import entities.Ordonnance;
import entities.Patient;
import entities.Rdv;
import entities.User;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;
import services.Service;
import views.ConnexionController;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class ListerConsultationMedecinController implements Initializable {
    private static ListerConsultationMedecinController ctrl;
    private final Service service = new Service(); 
    private User user;
    ObservableList<Consultation> ob;
    @FXML
    private Button use;
    @FXML
    private Button info;
    @FXML
    private Button out;
    @FXML
    private Button home;
    @FXML
    private TableColumn<Consultation, Date> tbdate;
    @FXML
    private TableColumn<Consultation, Ordonnance> tbordonnance;
    @FXML
    private TableColumn<Consultation, String> tbunarchived;
    @FXML
    private TableView<Consultation> tbconsultation;
    @FXML
    private TableColumn<Consultation, Patient> tbmedecin;
    @FXML
    private DatePicker filtreDateDeb;
    @FXML
    private DatePicker filtreDatefin;
    @FXML
    private TableColumn<Consultation, Consultation> action;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
         loadTableView();
        addButtonToTable();
         
    }    

    public static ListerConsultationMedecinController getCtrl() {
        return ctrl;
    }

    public User getUser() {
        return user;
    }

    @FXML
    private void handleuse(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Medecin/FonctionnaliteMedecin.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handleinfo(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Medecin/InfoMedecin.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handleout(ActionEvent event) throws IOException {
      int id = ConnexionController.getCtrl().getUser().getId();
      service.ChangeDispo(id, Boolean.FALSE);
      this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/connexion.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handlehome(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/userAccueil.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }
    
    private void loadTableView(){
        int id=ConnexionController.getCtrl().getUser().getId();
        List<Consultation> cons=service.showAllConsultationByMedecin(id);
        ob=FXCollections.observableArrayList(cons);
        tbconsultation.setItems(ob);
        //Construction des colonnes
        tbdate.setCellValueFactory(new PropertyValueFactory<>("date"));
        tbunarchived.setCellValueFactory(new PropertyValueFactory<>("unarchived"));
        tbmedecin.setCellValueFactory( new PropertyValueFactory<>("patient"));
        tbordonnance.setCellValueFactory(new PropertyValueFactory<>("ordonnance"));
        
    }
     private void addButtonToTable() {
        action.setCellFactory((TableColumn<Consultation, Consultation> param) -> new TableCellImpl());
    }

    @FXML
    private void handlefiltre(ActionEvent event) {
        int id=ConnexionController.getCtrl().getUser().getId();
        List<Consultation> cons=service.showAllConsultationByMedecin(id);
        ob=FXCollections.observableArrayList(cons);
        FilteredList<Consultation> filteredItems = new FilteredList<>(ob);
        // bind predicate based on datepicker choices
        filteredItems.predicateProperty().bind(Bindings.createObjectBinding(() -> {
            LocalDate minDate = filtreDateDeb.getValue();
            LocalDate maxDate = filtreDatefin.getValue();

            // get final values != null
            final LocalDate finalMin = minDate == null ? LocalDate.MIN : minDate;
            final LocalDate finalMax = maxDate == null ? LocalDate.MAX : maxDate;
            Date finalmin = java.sql.Date.valueOf( finalMin );
            Date finalmax =java.sql.Date.valueOf( finalMax );
            

            // values for openDate need to be in the interval [finalMin, finalMax]
            return ti -> !finalmin.after(ti.getDate()) && !finalmax.before(ti.getDate());
        },
                filtreDateDeb.valueProperty(),
                filtreDatefin.valueProperty()));

        tbconsultation.setItems(filteredItems);
    }
    private class TableCellImpl extends TableCell<Consultation, Consultation> {

        public TableCellImpl() {
        }
        private final FontAwesomeIcon delete = new FontAwesomeIcon();
        //private final FontAwesomeIcon delete = new FontAwesomeIcon();

        @Override
        protected void updateItem(Consultation item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setGraphic(null);
                return;
            }
            delete.setIcon(FontAwesomeIcons.ARCHIVE);
            delete.setFill(Paint.valueOf("#e81414"));
            delete.setCursor(Cursor.HAND);
            delete.setSize("3em");
            delete.setOnMouseClicked(event -> {
                Rdv getRdv = getTableView().getItems().get(getIndex());
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle(" CONFIRMATION ");
                alert.setContentText("Etes vous sur de vouloir effectuer cette action");
                Optional<ButtonType> option = alert.showAndWait();
                if(option.get()==ButtonType.OK){
                    service.annulerConsultation(getRdv.getId());
                    loadTableView();
                }
            });
            HBox pane = new HBox(delete);
            pane.setAlignment(Pos.CENTER);
            pane.setSpacing(20);
            setGraphic(pane);
        }
    }
}
