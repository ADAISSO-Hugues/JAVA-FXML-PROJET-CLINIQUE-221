/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views.Medecin;

import entities.User;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import services.Service;
import views.ConnexionController;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class FonctionnaliteMedecinController implements Initializable {
    private static FonctionnaliteMedecinController ctrl;
private AnchorPane anchorContent;
    @FXML
    private Button use;
    @FXML
    private Button info;
    @FXML
    private Button out;
    @FXML
    private Button home;
    
    private User user;
    @FXML
    private Button consultation;
    @FXML
    private Button rdv;
    @FXML
    private Button drdv;
    @FXML
    private Button showfile;
    private final Service service = new Service();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    public static FonctionnaliteMedecinController getCtrl() {
        return ctrl;
    }

    public User getUser() {
        return user;
    }

    @FXML
    private void handleuse(ActionEvent event) {
    }

    @FXML
    private void handleinfo(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Medecin/InfoMedecin.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handleout(ActionEvent event) throws IOException {
        int id = ConnexionController.getCtrl().getUser().getId();
        service.ChangeDispo(id, Boolean.FALSE);
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/connexion.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handlehome(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/userAccueil.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void listerconcsultation(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Medecin/listerConsultationMedecin.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void listerrdv(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Medecin/listerRdvMedecin.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }
    @FXML
    private void dordv(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Medecin/doRdvMedecin.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void showfile(ActionEvent event) throws IOException {
       this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Medecin/dossierPatient.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }
    
}
