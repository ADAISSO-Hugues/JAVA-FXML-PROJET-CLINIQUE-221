/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views.Medecin;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import services.Service;
import views.ConnexionController;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class InfoMedecinController implements Initializable {
private final Service service = new Service();
    @FXML
    private Button use;
    @FXML
    private Button info;
    @FXML
    private Button out;
    @FXML
    private Button home;
    @FXML
    private Text TXTNOM;
    @FXML
    private Text TXTLOGIN;
    @FXML
    private final ObservableList ob = FXCollections.observableArrayList() ;
    @FXML
    private Text txtpassword;
    @FXML
    private Text txtsta;
    @FXML
    private Text txtdispo;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
         int id =ConnexionController.getCtrl().getMedecin().getId();
    //loadComboBox(id);
       
        String nom =ConnexionController.getCtrl().getUser().getNomComplet();
        TXTNOM.setText("NOM : "+ nom);
        String login =ConnexionController.getCtrl().getUser().getLogin();
        TXTLOGIN.setText("LOGIN : "+ login);
        String statut = ConnexionController.getCtrl().getMedecin().getStatut();
        String password = ConnexionController.getCtrl().getUser().getPassword();
        Boolean disponible = ConnexionController.getCtrl().getMedecin().getDisponible();
        txtsta.setText("Statut : " + statut);
        txtpassword.setText(password);
        txtdispo.setText("Disponibilité : " + disponible);
        txtpassword.setVisible(false);
         
    }     
    @FXML
    private void handleuse(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Medecin/FonctionnaliteMedecin.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handleinfo(ActionEvent event) {
        
    }

    @FXML
    private void handleout(ActionEvent event) throws IOException {
        int id = ConnexionController.getCtrl().getUser().getId();
        service.ChangeDispo(id, Boolean.FALSE);
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/connexion.fxml"));
        Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handlehome(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/userAccueil.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handlepassword(ActionEvent event) {
        txtpassword.setVisible(true);
    }
    
}
