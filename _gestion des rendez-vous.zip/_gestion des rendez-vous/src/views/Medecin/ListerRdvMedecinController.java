/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views.Medecin;

import entities.Patient;
import entities.Rdv;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import services.Service;
import views.ConnexionController;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class ListerRdvMedecinController implements Initializable {
private final Service service = new Service();
    @FXML
    private Button use;
    @FXML
    private Button info;
    @FXML
    private Button out;
    @FXML
    private Button home;
    @FXML
    private TableColumn<Rdv, String> tbtype;
    @FXML
    private TableColumn<Rdv, ?> tbdate;
    @FXML
    private TableColumn<Rdv, Boolean> tbunarchived;
    @FXML
    private TableView<Rdv> tbrdv;
ObservableList<Rdv> ob;
    @FXML
    private TableColumn<Rdv, Patient> tbpat;
    private final Service ser= new Service();
    int id = ConnexionController.getCtrl().getUser().getId();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        loadTableView();
    }    
@FXML
    private void handleuse(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Medecin/FonctionnaliteMedecin.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handleinfo(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Medecin/InfoMedecin.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handleout(ActionEvent event) throws IOException {
      ser.ChangeDispo(id,false);
      this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/connexion.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handlehome(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/userAccueil.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }
    
    private void loadTableView(){
        List<Rdv> rdvs=service.showAllRendezVousByMedecin(LocalDate.now(),id);
        ob=FXCollections.observableArrayList(rdvs);
        //Construction des colonnes
        tbdate.setCellValueFactory(new PropertyValueFactory<>("date"));
        tbunarchived.setCellValueFactory(new PropertyValueFactory<>("unarchived"));
        tbtype.setCellValueFactory(new PropertyValueFactory<>("type"));
        tbpat.setCellValueFactory(new PropertyValueFactory<>("patient"));
        tbrdv.setItems(ob);
    }
    
}
