/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views.Medecin;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcons;
import entities.Consultation;
import entities.Ordonnance;
import entities.Patient;
import entities.Prestation;
import entities.Rdv;
import entities.ResponsablePrestation;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Paint;
import javafx.stage.Modality;
import javafx.stage.Stage;
import services.Service;
import views.ConnexionController;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class DossierPatientController implements Initializable {
private final Service service = new Service();
    @FXML
    private Button use;
    @FXML
    private Button info;
    @FXML
    private Button out;
    @FXML
    private Button home;
    @FXML
    private TableView<Patient> tbrdv;
ObservableList<Patient> ob;
    @FXML
    private TableColumn<Patient, Integer> tbid;
    @FXML
    private TableColumn<Patient, String> tbnom;
    @FXML
    private TableColumn<Patient, String> tbcode;
    @FXML
    private TableColumn<Patient, Patient> action;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    try {
        // TODO
        loadTableView();
    } catch (SQLException ex) {
        Logger.getLogger(DossierPatientController.class.getName()).log(Level.SEVERE, null, ex);
    }
        addButtonToTable();
    }    
@FXML
    private void handleuse(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Medecin/FonctionnaliteMedecin.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handleinfo(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Medecin/InfoMedecin.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handleout(ActionEvent event) throws IOException {
      int id = ConnexionController.getCtrl().getUser().getId();
      service.ChangeDispo(id, Boolean.FALSE);
      this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/connexion.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handlehome(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/userAccueil.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }
    
   private void loadTableView() throws SQLException {
      //  List<Rdv> rdvs = service.showAllPatient();
        int id = ConnexionController.getCtrl().getUser().getId();
            ob = FXCollections.observableArrayList(service.listPatient(id)) ;
            tbrdv.setItems(ob);
        //Construction des colonnes
        tbid.setCellValueFactory(new PropertyValueFactory<>("id"));
        tbnom.setCellValueFactory(new PropertyValueFactory<>("nomComplet"));
        tbcode.setCellValueFactory(new PropertyValueFactory<>("code"));

    }

    private void addButtonToTable() {
        action.setCellFactory((TableColumn<Patient, Patient> param) -> new TableCellImpl());
    }

    private class TableCellImpl extends TableCell<Patient, Patient> {

        public TableCellImpl() {
        }
        private final FontAwesomeIcon dossier = new FontAwesomeIcon();

        @Override
        protected void updateItem(Patient item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setGraphic(null);
                return;
            }
            dossier.setCursor(Cursor.HAND);
            dossier.setSize("3em");
            dossier.setIcon(FontAwesomeIcons.FOLDER);
            dossier.setFill(Paint.valueOf("#149a10"));
            dossier.setOnMouseClicked(new EventHandler<Event>() {
                Patient getPatient = getTableView().getItems().get(getIndex());
                final Stage primaryStage = new Stage();
                @Override
                public void handle(Event event) {
                    final Stage dialog = new Stage();
                    dialog.initModality(Modality.APPLICATION_MODAL);
                    dialog.initOwner(primaryStage);
                    VBox dialogVbox = new VBox(40);
                    int id = getPatient.getId();
                    TableView table = setTableView(id);
                    table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
                    table.setPrefWidth(800);
                    table.setPrefHeight(550);
                    DatePicker start = new DatePicker();
                    DatePicker end = new DatePicker();
                    start.setPromptText("start");
                    end.setPromptText("end");
                    Button filtre  = new Button("FILTRER");
                    filtre.setOnAction(param->{
                        filtreDate(id, start , end , table);
                    });
                    HBox d = new HBox();
                    d.setPadding(new Insets(30,0,0,0));
                    d.setAlignment(Pos.CENTER);
                    d.autosize();
                    d.getChildren().addAll(filtre , start , end);
                    
                    //creation de la fenetre
                    dialogVbox.getChildren().addAll(d,table);
                    Scene dialogScene = new Scene(dialogVbox, 800, 600);
                    dialog.setScene(dialogScene);
                    dialog.show();
                }    
            }); 
            HBox pane = new HBox(dossier);
            pane.setAlignment(Pos.CENTER);
            pane.setSpacing(20);
            setGraphic(pane);
    }
    }
    public void filtreDate(int id ,DatePicker filtreDateDeb , DatePicker filtreDatefin , TableView table){
        ObservableList obser = setObservablelist(id);
        FilteredList<?> filteredItems = new FilteredList<>(obser);
        // bind predicate based on datepicker choices
        filteredItems.predicateProperty().bind(Bindings.createObjectBinding(() -> {
            LocalDate minDate = filtreDateDeb.getValue();
            LocalDate maxDate = filtreDatefin.getValue();

            // get final values != null
            final LocalDate finalMin = minDate == null ? LocalDate.MIN : minDate;
            final LocalDate finalMax = maxDate == null ? LocalDate.MAX : maxDate;
            Date finalmin = java.sql.Date.valueOf(finalMin);
            Date finalmax = java.sql.Date.valueOf(finalMax);               
            // values for openDate need to be in the interval [finalMin, finalMax]
            
            return ti -> {
                return !finalmin.after(((Rdv)ti).getDate()) && !finalmax.before(((Rdv)ti).getDate());
            };
        },
                filtreDateDeb.valueProperty(),
                filtreDatefin.valueProperty()));

        table.setItems(filteredItems);
    }
   public ObservableList setObservablelist(int id) {
        ObservableList obser = FXCollections.observableArrayList(service.showfileDoByPatient(id));
        return obser;

    }
    public TableView setTableView(int id) {
        ObservableList obser = setObservablelist(id);
            TableView table = new TableView<>();
            table.setItems(obser);
            //creation table column
            TableColumn<Rdv , String> colType = new TableColumn<>("TYPE");
            colType.setStyle("-fx-alignment:CENTER");
            colType.setCellValueFactory(new PropertyValueFactory<>("type"));

            TableColumn<Rdv,Date> colDate = new TableColumn<>("DATE");
            colDate.setCellValueFactory(new PropertyValueFactory<>("date"));
            colDate.setStyle("-fx-alignment:CENTER");
            
 
            TableColumn<Rdv,String> colibelle = new TableColumn<>("LIBELLE");
            colibelle.setStyle("-fx-alignment:CENTER");
            colibelle.setCellValueFactory(new PropertyValueFactory<>("libellep"));
            
            TableColumn<Consultation, Ordonnance> colordonnance = new TableColumn<>("ORDONNANCE");
            colordonnance.setStyle("-fx-alignment:CENTER");
            colordonnance.setCellValueFactory(new PropertyValueFactory<>("ordonnance"));
            
            TableColumn<Prestation,ResponsablePrestation > colrespo = new TableColumn<>("RESPONSABLE");
            colrespo.setStyle("-fx-alignment:CENTER");
            colrespo.setCellValueFactory(new PropertyValueFactory<>("responsable"));
            
            table.getColumns().addAll(colType, colDate, colibelle , colordonnance , colrespo);
            return table;
            
    }
    
}
