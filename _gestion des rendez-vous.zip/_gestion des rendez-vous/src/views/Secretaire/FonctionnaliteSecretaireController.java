/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views.Secretaire;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcons;
import entities.Medecin;
import entities.Patient;
import entities.Rdv;
import entities.ResponsablePrestation;
import entities.User;
import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Paint;
import javafx.stage.Modality;
import javafx.stage.Stage;
import services.Service;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class FonctionnaliteSecretaireController implements Initializable {

    private static FonctionnaliteSecretaireController ctrl;
    private AnchorPane anchorContent;
    @FXML
    private Button use;
    @FXML
    private Button info;
    @FXML
    private Button out;
    @FXML
    private Button home;
    ObservableList<?> ob;

    private User user;
    @FXML
    private TableColumn<Rdv, String> tbtype;
    @FXML
    private TableColumn<Rdv, Date> tbdate;
    @FXML
    private TableColumn<Rdv, Patient> tbpatient;
    @FXML
    private TableColumn<Rdv, Boolean> tbunarchived;
    @FXML
    private TableView<Rdv> tbrdv;
    private final Service service = new Service();
    @FXML
    private TableColumn<Rdv, String> tblibelle;
    @FXML
    private TableColumn<Rdv, Rdv> action;
private final int nb =5;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        loadTableView();
        addButtonToTable();
    }

    public static FonctionnaliteSecretaireController getCtrl() {
        return ctrl;
    }

    public User getUser() {
        return user;
    }

    @FXML
    private void handleuse(ActionEvent event) {
    }

    @FXML
    private void handleinfo(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Secretaire/InfoSecretaire.fxml"));
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void handleout(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/connexion.fxml"));
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void handlehome(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/userAccueil.fxml"));
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void handledo(ActionEvent event) {
    }

    @FXML
    private void handleacteur(ActionEvent event) {

    }

    private void loadTableView() {
        List<Rdv> rdvs = service.showAllRendezVous();
        ob = FXCollections.observableArrayList(rdvs);
        tbrdv.setItems((ObservableList<Rdv>) ob);
        //Construction des colonnes
        tbtype.setCellValueFactory(new PropertyValueFactory<>("type"));
        tblibelle.setCellValueFactory(new PropertyValueFactory<>("libellep"));
        tbdate.setCellValueFactory(new PropertyValueFactory<>("date"));
        tbunarchived.setCellValueFactory(new PropertyValueFactory<>("unarchived"));
        tbpatient.setCellValueFactory(new PropertyValueFactory<>("patient"));

    }

    private void addButtonToTable() {
        action.setCellFactory((TableColumn<Rdv, Rdv> param) -> new TableCellImpl());
    }
    private class TableCellImpl extends TableCell<Rdv, Rdv> {
        public TableCellImpl() {
        }
        private final FontAwesomeIcon valider = new FontAwesomeIcon();
        //private final FontAwesomeIcon delete = new FontAwesomeIcon();

        @Override
        protected void updateItem(Rdv item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setGraphic(null);
                return;
            }
            valider.setCursor(Cursor.HAND);
            valider.setSize("3em");
            valider.setIcon(FontAwesomeIcons.EDIT);
            valider.setFill(Paint.valueOf("#149a10"));
            valider.setOnMouseClicked(new EventHandler<Event>() {
                Rdv getRdv = getTableView().getItems().get(getIndex());
                String type = getRdv.getType();
                final Stage primaryStage = new Stage();
                @Override
                public void handle(Event event) {
                    final Stage dialog = new Stage();
                    dialog.initModality(Modality.APPLICATION_MODAL);
                    dialog.initOwner(primaryStage);
                    HBox dialogHbox = new HBox(40);
                    TableView table = setTableView(type);
                    table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
                    table.setPrefWidth(600);
                    table.setPrefHeight(600);
                    final Button addButton = new Button("AFFECTER");
                    addButton.setOnAction(param->{
                        OnAction(type,table,getRdv,dialog);
                    });
                   
                    FontAwesomeIcon save = new FontAwesomeIcon();
                    save.setSize("5em");
                    save.setFill(Paint.valueOf("#149a10"));
                    save.setIcon(FontAwesomeIcons.HOSPITAL_ALT);
                    HBox centerbutton = new HBox();
                    //Setting the linear gradient to the circle and text 
                    centerbutton.setSpacing(5);
                    centerbutton.setAlignment(Pos.CENTER);
                    centerbutton.getChildren().addAll(addButton,save);
                    //creation de la fenetre
                    dialogHbox.getChildren().addAll(table,centerbutton);
                    Scene dialogScene = new Scene(dialogHbox, 800, 600);
                    dialog.setScene(dialogScene);
                    dialog.show();
                }
              

                
            });
           
            HBox pane = new HBox(valider);
            pane.setAlignment(Pos.CENTER);
            pane.setSpacing(20);
            setGraphic(pane);
        }
    }

    public ObservableList setObservablelist(String type) {
        if ("TYPE_CONSULTATION".equals(type)) {
            ObservableList<Medecin> obser = FXCollections.observableArrayList(service.listMedecinDispo());
            return obser; 
            }
            if ("TYPE_PRESTATION".equals(type)) {
            ObservableList<ResponsablePrestation> obser = FXCollections.observableArrayList(service.listResponsable());
            return obser;
        }
        return null;

    }
    private void OnAction(String type , TableView table, Rdv rdv,Stage dialog) {
        if(table.getSelectionModel().getSelectedItems().isEmpty()==false){
        if ("TYPE_CONSULTATION".equals(type)) {
           Medecin medecin = (Medecin) table.getSelectionModel().getSelectedItem();
           if(medecin.getNbr()<=nb){
           service.valideRdv(rdv.getId(),medecin.getId(),type,medecin.getNbr());
           }
            loadTableView(); 
            
        }
        if ("TYPE_PRESTATION".equals(type)) {
          ResponsablePrestation resp=(ResponsablePrestation) table.getSelectionModel().getSelectedItem();
         if(resp.getNbr()<=nb){
          service.valideRdv(rdv.getId(),resp.getId(),type , resp.getNbr());
         }
           loadTableView();
        }
         Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle(" Information ");
                alert.setContentText("Valider avec succes");
                alert.show();
                dialog.close();
        }else{
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle(" Information ");
                alert.setContentText("Veuillez selectionner svp ");
                alert.show();
        }
    }

    public TableView setTableView(String type) {
        ObservableList obser = setObservablelist(type);
        System.out.println("    "+obser);
        if ("TYPE_CONSULTATION".equals(type)) {
            TableView<Medecin> table = new TableView<>();
            table.setItems(obser);
            //creation table column
            TableColumn<Medecin, Integer> colId = new TableColumn<>("ID");
            colId.setStyle("-fx-alignment:CENTER");
            colId.setCellValueFactory(new PropertyValueFactory<>("id"));

            TableColumn<Medecin, String> colName = new TableColumn<>("Name");
            colName.setCellValueFactory(new PropertyValueFactory<>("nomComplet"));
            colName.setStyle("-fx-alignment:CENTER");
            table.getColumns().addAll(colId, colName);
            return table;
       }
        if ("TYPE_PRESTATION".equals(type)) {
            TableView<ResponsablePrestation> table = new TableView<>();
            table.setItems(obser);
            TableColumn<ResponsablePrestation, Integer> colId = new TableColumn<>("ID");
            colId.setStyle("-fx-alignment:CENTER");
            colId.setCellValueFactory(new PropertyValueFactory<>("id"));

            TableColumn<ResponsablePrestation, String> colName = new TableColumn<>("Name");
            colName.setStyle("-fx-alignment:CENTER");
            colName.setCellValueFactory(new PropertyValueFactory<>("nomComplet"));

            table.getColumns().addAll(colId, colName);
            return table;
        }
        //setTableView 
        return null;
    }
}
