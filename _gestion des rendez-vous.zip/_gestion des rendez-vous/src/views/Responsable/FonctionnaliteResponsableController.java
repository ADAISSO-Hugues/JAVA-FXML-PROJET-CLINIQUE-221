/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views.Responsable;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcons;
import entities.Patient;
import entities.Prestation;
import entities.Rdv;
import entities.User;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;
import services.Service;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class FonctionnaliteResponsableController implements Initializable {

    private static FonctionnaliteResponsableController ctrl;
    private AnchorPane anchorContent;
    @FXML
    private Button use;
    @FXML
    private Button info;
    @FXML
    private Button out;
    @FXML
    private Button home;
    ObservableList<Prestation> ob;

    private User user;
    @FXML
    private TableColumn<Prestation, Date> tbdate;
    @FXML
    private TableColumn<Prestation, Patient> tbpatient;
    @FXML
    private TableColumn<Prestation, Boolean> tbunarchived;
    @FXML
    private TableView<Prestation> tbrdv;
    private final Service service = new Service();
    @FXML
    private TableColumn<Prestation, String> tblibelle;
    @FXML
    private TableColumn<Prestation, Prestation> action;
    @FXML
    private DatePicker filtreDateDeb;
    @FXML
    private DatePicker filtreDatefin;
    @FXML
    private Button filtre;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        loadTableView();
        addButtonToTable();
    }

    public static FonctionnaliteResponsableController getCtrl() {
        return ctrl;
    }

    public User getUser() {
        return user;
    }

    @FXML
    private void handleuse(ActionEvent event) {
    }

    @FXML
    private void handleinfo(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Responsable/InfoResponsable.fxml"));
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void handleout(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/connexion.fxml"));
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void handlehome(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/userAccueil.fxml"));
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }


    private void loadTableView() {
        List<Prestation> prestations = service.showAllPrestation();
        ob = FXCollections.observableArrayList(prestations);
        tbrdv.setItems(ob);
        //Construction des colonnes
        tblibelle.setCellValueFactory(new PropertyValueFactory<>("libellep"));
        tbdate.setCellValueFactory(new PropertyValueFactory<>("date"));
        tbunarchived.setCellValueFactory(new PropertyValueFactory<>("unarchived"));
        tbpatient.setCellValueFactory(new PropertyValueFactory<>("patient"));
    }

    private void addButtonToTable() {
        action.setCellFactory((TableColumn<Prestation, Prestation> param) -> new TableCellImpl());
    }

    @FXML
    private void handlefiltre(ActionEvent event) {
        List<Prestation> prestations = service.showAllPrestation();
        ob = FXCollections.observableArrayList(prestations);
        FilteredList<Prestation> filteredItems = new FilteredList<>(ob);
        // bind predicate based on datepicker choices
        filteredItems.predicateProperty().bind(Bindings.createObjectBinding(() -> {
            LocalDate minDate = filtreDateDeb.getValue();
            LocalDate maxDate = filtreDatefin.getValue();

            // get final values != null
            final LocalDate finalMin = minDate == null ? LocalDate.MIN : minDate;
            final LocalDate finalMax = maxDate == null ? LocalDate.MAX : maxDate;
            Date finalmin = java.sql.Date.valueOf( finalMin );
            Date finalmax =java.sql.Date.valueOf( finalMax );
            

            // values for openDate need to be in the interval [finalMin, finalMax]
            return ti -> !finalmin.after(ti.getDate()) && !finalmax.before(ti.getDate());
        },
                filtreDateDeb.valueProperty(),
                filtreDatefin.valueProperty()));

        tbrdv.setItems(filteredItems);
    }
    private class TableCellImpl extends TableCell<Prestation, Prestation> {

        public TableCellImpl() {
        }
        private final FontAwesomeIcon delete = new FontAwesomeIcon();
        //private final FontAwesomeIcon delete = new FontAwesomeIcon();

        @Override
        protected void updateItem(Prestation item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setGraphic(null);
                return;
            }
            delete.setIcon(FontAwesomeIcons.ARCHIVE);
            delete.setFill(Paint.valueOf("#e81414"));
            delete.setCursor(Cursor.HAND);
            delete.setSize("3em");
            delete.setOnMouseClicked(event -> {
                Rdv getRdv = getTableView().getItems().get(getIndex());
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle(" CONFIRMATION ");
                alert.setContentText("Etes vous sur de vouloir effectuer cette action");
                Optional<ButtonType> option = alert.showAndWait();
                if(option.get()==ButtonType.OK){
                    service.annulerPrestation(getRdv.getId());
                    loadTableView();
                }
            });
            HBox pane = new HBox(delete);
            pane.setAlignment(Pos.CENTER);
            pane.setSpacing(20);
            setGraphic(pane);
        }
    }
}
