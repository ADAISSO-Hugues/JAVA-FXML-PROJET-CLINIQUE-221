/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import services.Service;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class UserAccueilController implements Initializable {

    @FXML
    private Text txtprofil;
    @FXML
    private Button use;
    @FXML
    private Button info;
    @FXML
    private Button out;
    @FXML
    private Button home;
    @FXML
    private ToggleButton oui;
    private final Service ser = new Service();
    int id = ConnexionController.getCtrl().getUser().getId();
    String role =ConnexionController.getCtrl().getUser().getRole();
    @FXML
    private Text txt;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        String nom =ConnexionController.getCtrl().getUser().getNomComplet();
        txtprofil.setText("\t\t"+ nom);
        if("ROLE_MEDECIN".equals(role)){
            Boolean disp = ser.Etat(id);
            if(disp.equals(true)){
                oui.setText("NON");
            }else{
                oui.setText("OUI");
            }
        }else{
            oui.setVisible(false);
            txt.setVisible(false);
            
        }
    }    
  @FXML
    private void handleuse(ActionEvent event) throws IOException {
        this.txtprofil.getScene().getWindow().hide();
        AnchorPane root = null;
        if("ROLE_MEDECIN".equals(role)){
        root = FXMLLoader.load(getClass().getResource("/views/Medecin/FonctionnaliteMedecin.fxml"));
        }
         if("ROLE_PATIENT".equals(role)){
        root = FXMLLoader.load(getClass().getResource("/views/Patient/FonctionnalitePatient.fxml"));
        }
          if("ROLE_RESPONSABLE".equals(role)){
        root = FXMLLoader.load(getClass().getResource("/views/Responsable/FonctionnaliteResponsable.fxml"));
        }
           if("ROLE_SECRETAIRE".equals(role)){
        root = FXMLLoader.load(getClass().getResource("/views/Secretaire/FonctionnaliteSecretaire.fxml"));
        }
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handleinfo(ActionEvent event) throws IOException {
        this.txtprofil.getScene().getWindow().hide();
        AnchorPane root = null;
        if("ROLE_MEDECIN".equals(role)){
        root = FXMLLoader.load(getClass().getResource("/views/Medecin/InfoMedecin.fxml"));
        }
        if("ROLE_PATIENT".equals(role)){
        root = FXMLLoader.load(getClass().getResource("/views/Patient/InfoPatient.fxml"));
        }
        if("ROLE_RESPONSABLE".equals(role)){
        root = FXMLLoader.load(getClass().getResource("/views/Responsable/InfoResponsable.fxml"));
        }
        if("ROLE_SECRETAIRE".equals(role)){
        root = FXMLLoader.load(getClass().getResource("/views/Secretaire/InfoSecretaire.fxml"));
        }
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handleout(ActionEvent event) {
        ser.ChangeDispo(id,true);
        this.txtprofil.getScene().getWindow().hide();
              AnchorPane root = null;   
              try {
                  root = FXMLLoader.load(getClass().getResource("/views/connexion.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
              } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
              }
    }
    @FXML
    private void handlehome(ActionEvent event) {
    }
    @FXML
    private void handleoui(ActionEvent event) {
        if("ROLE_MEDECIN".equals(role)){
            if("OUI".equals(oui.getText())){
            ser.ChangeDispo(id,true);
            oui.setText("NON");
            }else{
            ser.ChangeDispo(id,false);
            oui.setText("OUI");
            }
        }
    }
}
