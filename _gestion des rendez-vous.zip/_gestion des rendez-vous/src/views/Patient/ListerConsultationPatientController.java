/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views.Patient;

import entities.Consultation;
import entities.Medecin;
import entities.Ordonnance;
import entities.User;
import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import services.Service;
import views.ConnexionController;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class ListerConsultationPatientController implements Initializable {
    private static ListerConsultationPatientController ctrl;
    private final Service service = new Service(); 
    private User user;
    ObservableList<Consultation> ob;
    @FXML
    private Button use;
    @FXML
    private Button info;
    @FXML
    private Button out;
    @FXML
    private Button home;
    @FXML
    private TableColumn<Consultation, Date> tbdate;
    @FXML
    private TableColumn<Consultation, Ordonnance> tbordonnance;
    @FXML
    private TableColumn<Consultation, String> tbunarchived;
    @FXML
    private TableView<Consultation> tbconsultation;
    @FXML
    private TableColumn<Consultation, Medecin> tbmedecin;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
         loadTableView();
         
    }    

    public static ListerConsultationPatientController getCtrl() {
        return ctrl;
    }

    public User getUser() {
        return user;
    }

    @FXML
    private void handleuse(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Patient/FonctionnalitePatient.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handleinfo(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Patient/InfoPatient.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handleout(ActionEvent event) throws IOException {
      this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/connexion.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handlehome(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/userAccueil.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }
    
    private void loadTableView(){
        int id=ConnexionController.getCtrl().getUser().getId();
        List<Consultation> cons=service.showAllConsultationByPatient(id);
        ob=FXCollections.observableArrayList(cons);
        //Construction des colonnes
        tbdate.setCellValueFactory(new PropertyValueFactory<>("date"));
        tbunarchived.setCellValueFactory(new PropertyValueFactory<>("unarchived"));
        tbmedecin.setCellValueFactory( new PropertyValueFactory<>("medecin"));
        tbordonnance.setCellValueFactory(new PropertyValueFactory<>("ordonnance"));
        tbconsultation.setItems(ob);
    }
}
