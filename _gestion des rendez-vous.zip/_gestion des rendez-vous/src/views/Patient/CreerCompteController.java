/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views.Patient;

import entities.Antecedent;
import entities.Patient;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import services.Service;
import views.ConnexionController;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class CreerCompteController implements Initializable {
    private final Service service = new Service();
    private AnchorPane anchorContent;
    @FXML
    private ComboBox<Antecedent> cboantecedent;
    @FXML
    private TextField txtNom;
    @FXML
    private TextField txtlogin;
    @FXML
    private TextField txtCode;
    @FXML
    private PasswordField txtPassword;
    @FXML
    private Text txtError;
    private ObservableList ob = FXCollections.observableArrayList() ;
     
    @Override
    public void initialize(URL url, ResourceBundle rb) {
            loadComboBox();
            txtError.setVisible(false);
    }    
    
      private void loadView(String view) throws IOException{
        AnchorPane root;
        root = FXMLLoader.load(getClass().getResource("/views/"+view+".fxml"));
        anchorContent.getChildren().clear();
        anchorContent.getChildren().add(root);
    }
   
       public void loadComboBox(){
            ob = FXCollections.observableArrayList(service.listAnte()) ;
            cboantecedent.setItems(ob);
    } 

    @FXML
    private void handleConnexion(ActionEvent event) throws IOException, SQLException {
            String login = txtlogin.getText().trim();
            String password = txtPassword.getText().trim();
            String code = txtCode.getText().trim();
            String nom = txtNom.getText().trim();
            Antecedent antecedent = cboantecedent.getSelectionModel().getSelectedItem();
        
            if(login.isEmpty() || password.isEmpty())
            {
                txtError.setText("login ou le mot de passe Obligatoire");
                txtError.setVisible(true);
            }else{
                if(code.isEmpty() || nom.isEmpty()){
                 txtError.setText("champ mal rempli ou obligatoire");  
                 txtError.setVisible(true);
                }
                else{
                    Patient patient = new Patient(code , nom , login , password , antecedent);
                    service.addCompte(patient);
                   AnchorPane root = null;

                   try {
                       root = FXMLLoader.load(getClass().getResource("/views/connexion.fxml"));
                       Scene scene = new Scene(root);
                       Stage stage = new Stage();
                       stage.setScene(scene);
                       stage.show();
                   } catch (IOException ex) {
                       Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
                   }

                   //Cache la fénétre de connexion
                    this.txtlogin.getScene().getWindow().hide();
                }
            }
   }

    @FXML
    private void handleAntecedent(ActionEvent event) {
         Antecedent antecedent = cboantecedent.getSelectionModel().getSelectedItem();
    }
}

  