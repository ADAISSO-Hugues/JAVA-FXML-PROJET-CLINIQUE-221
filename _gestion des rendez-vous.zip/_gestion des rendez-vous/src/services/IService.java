/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entities.Consultation;
import entities.Patient;
import entities.Prestation;
import entities.Rdv;
import entities.User;
import java.time.LocalDate;
import java.util.List;

/**
 *
 * @author hp
 */
public interface IService {
       public User login(String login, String password);
       public List<Rdv> showAllRendezVousByMedecin(LocalDate date, int id);
       public List<Rdv> showAllRendezVousDoByPatient(int id);//(1) selecter le patient
       public List<Patient> showAllPatient();
       public void showDetailsOneConsultation(int id);
       public List<Consultation> showAllConsultationByMedecin(int id);
       public void annulerConsultation(int id);
       //deja fait use patient 28/10/2021
       //use case Patient
       public void addCompte(Patient patient);
      // public List<Rdv> showAllRendezVousDoByPatient();
       public List<Consultation> showAllConsultationByPatient(int id);//(1)
       public List<Prestation> showAllPrestationByPatient(int id);//(1)
       public List<Rdv> showAllRendezVous(int id);
       //deja fait use secretaire 30/10/2021 
       // use case Secretaire
       public List<Rdv> showAllRendezVous();
       public void valideRdv(int id, int idInsert,String type , int idnbr);
       public void annulerRendezVous(int id);   
       // deja fait use case Responsable Prestation
        public List<Prestation> showAllPrestation();
        public void annulerPrestation(int id);
        public void showDetailsPrestation(int id);   
}
