/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author hp
 */
public class Secretaire extends User{
  private final String ROLE="ROLE_SECRETAIRE";   

    public Secretaire(int id, String nomComplet) {
        super(id, nomComplet);
        this.role = ROLE;
    }

    public Secretaire() {
        this.role=ROLE;
    }

    public Secretaire(String nomComplet) {
        super(nomComplet);
    }
    
}
