/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author hp
 */
public class Prescription {
    private int id_medicament;
    private int id_ordonnance;

    public int getId_medicament() {
        return id_medicament;
    }

    public void setId_medicament(int id_medicament) {
        this.id_medicament = id_medicament;
    }

    public int getId_ordonnance() {
        return id_ordonnance;
    }

    public void setId_ordonnance(int id_ordonnance) {
        this.id_ordonnance = id_ordonnance;
    }

    public Prescription(int id_medicament, int id_ordonnance) {
        this.id_medicament = id_medicament;
        this.id_ordonnance = id_ordonnance;
    }

    public Prescription() {
    }
    
}
