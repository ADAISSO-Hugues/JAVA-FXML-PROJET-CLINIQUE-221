/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.Date;

/**
 *
 * @author hp
 */
public class Prestation extends Rdv {
    private String libellep;
    private Consultation consultation;
    private ResponsablePrestation responsable;
     private final String TYPE="TYPE_PRESTATION";

    public Prestation(int aInt, String string, int aInt0, int aInt1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getLibellep() {
        return libellep;
    }

    public void setLibellep(String libellep) {
        this.libellep = libellep;
    }

    public Consultation getConsultation() {
        return consultation;
    }

    public void setConsultation(Consultation consultation) {
        this.consultation = consultation;
    }

    public ResponsablePrestation getResponsable() {
        return responsable;
    }

    public void setResponsable(ResponsablePrestation responsable) {
        this.responsable = responsable;
    }

    public Prestation() {
         this.type = TYPE;
    }

    
    
}
