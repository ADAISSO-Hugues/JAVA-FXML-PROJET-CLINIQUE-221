/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;

/**
 *
 * @author hp
 */
public class Medecin extends User {
    private String statut ;
    private Boolean disponible;
    private final String ROLE="ROLE_MEDECIN";


    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public Boolean getDisponible() {
        return disponible;
    }

    public void setDisponible(Boolean disponible) {
        this.disponible = disponible;
    }

    public Medecin(String statut, Boolean disponible, String nomComplet) {
        super(nomComplet);
        this.statut = statut;
        this.disponible = disponible;
        this.role =ROLE;
    }

    public Medecin(String statut, Boolean disponible, int id, String nomComplet) {
        super(id, nomComplet);
        this.statut = statut;
        this.disponible = disponible;
        this.role=ROLE;
    }

    public Medecin() {
        this.role=ROLE;
    }

    @Override
   public String toString(){
       return nomComplet;
   }
    
}
