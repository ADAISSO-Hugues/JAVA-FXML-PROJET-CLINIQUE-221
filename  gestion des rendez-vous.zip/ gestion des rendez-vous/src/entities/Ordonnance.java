/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;

/**
 *
 * @author hp
 */
public class Ordonnance {
    private int id;
    private String posologie;

    public Ordonnance(int aInt, int aInt0, Object object, int aInt1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPosologie() {
        return posologie;
    }

    public void setPosologie(String posologie) {
        this.posologie = posologie;
    }


    public Ordonnance() {
    }

    public Ordonnance(int id, String posologie) {
        this.id = id;
        this.posologie = posologie;
      ;
    }

    public Ordonnance(String posologie) {
        this.posologie = posologie;
        
    }
    @Override
    public String toString(){
       return " "+posologie;
   }
    
}
