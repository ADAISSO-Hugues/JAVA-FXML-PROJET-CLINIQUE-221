/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;

/**
 *
 * @author hp
 */
public class Ordonnance {
    private int id;
    private int posologie;
    private Medicament medicament;
    private Consultation consultation;

    public Ordonnance(int aInt, int aInt0, Object object, int aInt1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Consultation getConsultation() {
        return consultation;
    }

    public void setConsultation(Consultation consultation) {
        this.consultation = consultation;
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPosologie() {
        return posologie;
    }

    public void setPosologie(int posologie) {
        this.posologie = posologie;
    }

    public Medicament getMedicament() {
        return medicament;
    }

    public void setMedicament(Medicament medicament) {
        this.medicament = medicament;
    }

  

    public Ordonnance() {
    }

    public Ordonnance(int id, int posologie, Medicament medicament) {
        this.id = id;
        this.posologie = posologie;
        this.medicament = medicament;
    }

    public Ordonnance(int posologie, Medicament medicament) {
        this.posologie = posologie;
        this.medicament = medicament;
    }
    
}
