/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author hp
 */
public class ConCons {
    private int id_consultation;
    private int id_constante;

    public int getId_consultation() {
        return id_consultation;
    }

    public void setId_consultation(int id_consultation) {
        this.id_consultation = id_consultation;
    }

    public int getId_constante() {
        return id_constante;
    }

    public void setId_constante(int id_constante) {
        this.id_constante = id_constante;
    }

    public ConCons(int id_consultation, int id_constante) {
        this.id_consultation = id_consultation;
        this.id_constante = id_constante;
    }

    public ConCons() {
    }
    
}
