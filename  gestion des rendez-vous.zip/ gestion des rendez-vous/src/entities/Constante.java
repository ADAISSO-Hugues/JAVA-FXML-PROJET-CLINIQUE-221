/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author hp
 */
public class Constante {
    private int id ;
    private String libellec;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLibellec() {
        return libellec;
    }

    public void setLibellec(String libellec) {
        this.libellec = libellec;
    }

    public Constante() {
    }

    public Constante(String libellec) {
        this.libellec = libellec;
    }

    public Constante(int id, String libellec) {
        this.id = id;
        this.libellec = libellec;
    }
        @Override
   public String toString(){
       return libellec;
   }
    
}
