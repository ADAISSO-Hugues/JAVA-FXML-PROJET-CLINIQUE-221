/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;

/**
 *
 * @author hp
 */
public class ResponsablePrestation extends User {
 private final String ROLE="ROLE_RESPONSABLE";
    public ResponsablePrestation() {
                this.role=ROLE;
    }

    public ResponsablePrestation(int id, String nomComplet) {
        super(id, nomComplet);
                this.role=ROLE;
    }

    public ResponsablePrestation(String nomComplet) {
        super(nomComplet);
                this.role=ROLE;
    }
 @Override
    public String toString(){
     return nomComplet;
        
    }
    
}
