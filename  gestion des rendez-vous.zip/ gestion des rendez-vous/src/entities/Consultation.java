/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.Date;
import java.util.List;

/**
 *
 * @author hp
 */
public class Consultation extends Rdv {
    private Medecin medecin ;
   // private List<Constante> constantes;
    private Constante constante;
     private Ordonnance ordonnance ;
    private Prestation prestation;

    public Constante getConstante() {
        return constante;
    }

    public void setConstante(Constante constante) {
        this.constante = constante;
    }
    
/*
    public List<Constante> getConstantes() {
        return constantes;
    }

    public void setConstantes(List<Constante> constantes) {
        this.constantes = constantes;
    }
*/
   
     private final String TYPE = "TYPE_coNSULTATION";

    public Medecin getMedecin() {
        return medecin;
    }

    public void setMedecin(Medecin medecin) {
        this.medecin = medecin;
    }


    public Ordonnance getOrdonnance() {
        return ordonnance;
    }

    public void setOrdonnance(Ordonnance ordonnance) {
        this.ordonnance = ordonnance;
    }

    public Prestation getPrestation() {
        return prestation;
    }

    public void setPrestation(Prestation prestation) {
        this.prestation = prestation;
    }


    public Consultation() {
        this.type = TYPE;
    }

    public Consultation(Medecin medecin, Constante constante, Ordonnance ordonnance, Prestation prestation, Date date, String type, Boolean unarchived) {
        super(date, type, unarchived);
        this.medecin = medecin;
        this.constante = constante;
        this.ordonnance = ordonnance;
        this.prestation = prestation;
    }

    public Consultation(Medecin medecin, Constante constante, Ordonnance ordonnance, Prestation prestation, int id, Date date, String type, Boolean unarchived, Patient patient) {
        super(id, date, type, unarchived, patient);
        this.medecin = medecin;
        this.constante = constante;
        this.ordonnance = ordonnance;
        this.prestation = prestation;
    }

    public Consultation(Medecin medecin, Constante constante, Ordonnance ordonnance, Prestation prestation, int id, Date date, String type, Boolean unarchived) {
        super(id, date, type, unarchived);
        this.medecin = medecin;
        this.constante = constante;
        this.ordonnance = ordonnance;
        this.prestation = prestation;
    }

    public Consultation(Medecin medecin, Constante constante, Ordonnance ordonnance, Prestation prestation, Date date, String type, Boolean unarchived, Patient patient) {
        super(date, type, unarchived, patient);
        this.medecin = medecin;
        this.constante = constante;
        this.ordonnance = ordonnance;
        this.prestation = prestation;
    }

   

   

   
    
}
