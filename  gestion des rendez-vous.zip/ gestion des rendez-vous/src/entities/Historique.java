/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author hp
 */
public class Historique {
    private int id_antecedent;
    private int id_patient;

    public int getId_antecedent() {
        return id_antecedent;
    }

    public void setId_antecedent(int id_antecedent) {
        this.id_antecedent = id_antecedent;
    }

    public int getId_patient() {
        return id_patient;
    }

    public void setId_patient(int id_patient) {
        this.id_patient = id_patient;
    }

    public Historique() {
    }

    public Historique(int id_antecedent, int id_patient) {
        this.id_antecedent = id_antecedent;
        this.id_patient = id_patient;
    }
    
}
