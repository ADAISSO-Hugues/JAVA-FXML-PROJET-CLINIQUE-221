/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;

/**
 *
 * @author hp
 */
public class Patient extends User{
    private String code;
    private Antecedent antecedent;
    private Rdv rdv;

    public Patient(String code, String nom, String login, String password, Antecedent antecedent) {
        super(nom, login, password);
        this.code = code;
        this.antecedent = antecedent;
        this.role=ROLE;
    }


    public Rdv getRdv() {
        return rdv;
    }

    public void setRdv(Rdv rdv) {
        this.rdv = rdv;
    }
   
    
    public Antecedent getAntecedent() {
        return antecedent;
    }

    public void setAntecedent(Antecedent antecedent) {
        this.antecedent = antecedent;
    }

 
     private final String ROLE="ROLE_PATIENT";

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Patient() {
                this.role=ROLE;
    }

    public Patient(String code, int id, String nomComplet ) {
        super(id, nomComplet);
        this.code = code;
        this.role=ROLE;

    }

    public Patient(String code, String nomComplet) {
        super(nomComplet);
        this.code = code;
                        this.role=ROLE;

    }

    public Patient(String code, String nomComplet, String login, String password) {
        super(nomComplet, login, password);
        this.code = code;
        this.role=ROLE;
    }

    public Patient(String code, Antecedent antecedent, int id, String nomComplet, String login, String password, String role) {
        super(id, nomComplet, login, password, role);
        this.code = code;
        this.role=ROLE;
        this.antecedent = antecedent;
    }
    
    
    
}
