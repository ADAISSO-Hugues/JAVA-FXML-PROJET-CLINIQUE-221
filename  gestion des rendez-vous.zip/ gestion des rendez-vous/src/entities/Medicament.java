/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;

/**
 *
 * @author hp
 */
public class Medicament {
    private int id;
    private String nom;
    private String code;
    private Ordonnance ordonnance;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Ordonnance getOrdonnance() {
        return ordonnance;
    }

    public void setOrdonnance(Ordonnance ordonnance) {
        this.ordonnance = ordonnance;
    }

    public Medicament(int id, String nom, String code) {
        this.id = id;
        this.nom = nom;
        this.code = code;
    }

    public Medicament(String nom, String code) {
        this.nom = nom;
        this.code = code;
    }

    public Medicament() {
    }
    
}
