/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import dao.AntecedentDao;
import dao.ConConsDao;
import dao.ConstanteDao;
import dao.ConsultationDao;
import dao.HistoriqueDao;
import dao.MedecinDao;
import dao.MedicamentDao;
import dao.OrdonnanceDao;
import dao.PatientDao;
import dao.PrescriptionDao;
import dao.PrestationDao;
import dao.RdvDao;
import dao.ResponsablePrestationDao;
import dao.SecretaireDao;
import dao.UserDao;
import entities.Antecedent;
import entities.Constante;
import entities.Consultation;
import entities.Historique;
import entities.Medecin;
import entities.Ordonnance;
import entities.Patient;
import entities.Prestation;
import entities.Rdv;
import entities.ResponsablePrestation;
import entities.User;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hp
 */
public class Service implements IService {
      UserDao daoUser=new UserDao();
      AntecedentDao daoAntecedent = new AntecedentDao();
      ConstanteDao daoConstante = new ConstanteDao();
      ConsultationDao daoConsultation=new ConsultationDao();
      MedecinDao daoMedecin = new MedecinDao();
      MedicamentDao daoMedicament = new MedicamentDao();
      OrdonnanceDao daoOrdonnance =new OrdonnanceDao();
      PatientDao daoPatient = new PatientDao();
      PrestationDao daoPrestation = new PrestationDao();
      RdvDao daoRdv = new RdvDao();
      SecretaireDao daoSecretaire = new SecretaireDao();
      ResponsablePrestationDao daoResponsablePrestation = new ResponsablePrestationDao();
      HistoriqueDao daoHistorique = new HistoriqueDao();
      PrescriptionDao daoPrescription =new PrescriptionDao();
      ConConsDao daoConCons = new ConConsDao();

    public PatientDao getDaoPatient() {
        return daoPatient;
    }
      
      
      @Override
        public User login(String login, String password) {
            return daoUser.findUserLoginAndPassword(login, password);
        
        
         
}   public List<Antecedent> listAnte(){
        List<Antecedent> antecedent = daoAntecedent.findAll();
        return antecedent;
}
public List<Antecedent> listAnten(int id) throws SQLException{
    List<Antecedent> antecedent= new ArrayList<>();
        List<Historique> histo = daoHistorique.findAllBy(id);
        if(!histo.isEmpty()){
            for(Historique his : histo){
                Antecedent antec = daoAntecedent.findById(his.getId_antecedent());
                antecedent.add(antec);
            }
            return antecedent ;
        }
        return antecedent;
}   
    @Override
    public Rdv doRendezVous() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Rdv> showAllRendezVousByMedecin(int id) {
        List<Rdv> rdvs =new ArrayList<>();
          try {
              rdvs = daoRdv.findAllById_Medecin(id);
          } catch (SQLException ex) {
              Logger.getLogger(Service.class.getName()).log(Level.SEVERE, null, ex);
          }
        return rdvs;
    }

    @Override
    public List<Rdv> showAllRendezVousDoByPatient( int id) {
        List<Rdv> rdvs =new ArrayList<>();
          try {
              rdvs = daoRdv.findAllById_Patient(id);
          } catch (SQLException ex) {
              Logger.getLogger(Service.class.getName()).log(Level.SEVERE, null, ex);
          }
        return rdvs;
    }

    @Override
    public List<Patient> showAllPatient() {
        List<Patient> patients=new ArrayList<>();
        patients = daoPatient.findAll();
        return patients;
    }
    public List<Consultation> showAllConsultation() {
        List<Consultation> cons=new ArrayList<>();
        cons = daoConsultation.findAll();
        return cons;
    }

    @Override
    public void showDetailsOneConsultation(int id) {
        Consultation consultation = daoConsultation.findById(id);
        Medecin medecin= consultation.getMedecin();
        Patient patient=consultation.getPatient();
        Ordonnance ordonnance = consultation.getOrdonnance();
        Date date = consultation.getDate();
        boolean unarchived = consultation.getUnarchived();
    }

    @Override
    public List<Consultation> showAllConsultationByMedecin(int id) {
        List<Consultation> consultations =new ArrayList<>();
          try {
              consultations = daoConsultation.findAllById_Medecin(id);
          } catch (SQLException ex) {
              Logger.getLogger(Service.class.getName()).log(Level.SEVERE, null, ex);
          }
        return consultations;
    }

    @Override
    public void AnnulerConsultation(int id) {
        Consultation consultation = daoConsultation.findById(id);
        consultation.setUnarchived(Boolean.FALSE);
          int nbr = daoConsultation.update(consultation);
    }

    @Override
    public void addCompte(Patient patient) {
        daoPatient.insert1(patient);
    }

    @Override
    public Rdv askRendezVous() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Consultation> showAllConsultationByPatient(int id) {
        List<Consultation> consultations =new ArrayList<>();
          try {
              consultations = daoConsultation.findAllById_Patient(id);
          } catch (SQLException ex) {
              Logger.getLogger(Service.class.getName()).log(Level.SEVERE, null, ex);
          }
        return consultations;
    }

    @Override
    public List<Prestation> showAllPrestationByPatient(int id) {
         List<Prestation> prestations =new ArrayList<>();
          try {
              prestations = daoPrestation.findAllById(id);
          } catch (SQLException ex) {
              Logger.getLogger(Service.class.getName()).log(Level.SEVERE, null, ex);
          }
        return prestations;
    }
    public List<Medecin> listMedecinDispo(){
            List<Medecin> medecins = daoMedecin.findAll();
          return medecins;
        
    }
    public List<ResponsablePrestation> listResponsable(){
        List<ResponsablePrestation> rps=daoResponsablePrestation.findAll();
        return rps;
        
    }

    @Override
    public List<Rdv> showAllRendezVous(int id) {
         List<Rdv> rdvs=new ArrayList<>();
        rdvs = daoRdv.findAl(id);
        return rdvs;
    }
    @Override
    public List<Rdv> showAllRendezVous() {
         List<Rdv> rdvs=new ArrayList<>();
        rdvs = daoRdv.findAll();
        return rdvs;
    }

    @Override
    public void valideRdv(int id,int idInsert,String type) {
        Rdv rdv = daoRdv.findById(id);
         rdv.setUnarchived(Boolean.TRUE);
         if("TYPE_CONSULTATION".equals(type)) {
          int nbr = daoRdv.updateToConsultation(rdv,idInsert);
         }else{
             int nbr = daoRdv.updateToPrestation(rdv,idInsert);
         }
         
    }

    @Override
    public void annulerRendezVous(int id) {
        Rdv rdv = daoRdv.findById(id);
        rdv.setUnarchived(Boolean.FALSE);
        int nbr = daoRdv.update(rdv);
    }

    @Override
    public List<Prestation> showAllPrestation() {
         List<Prestation> prestations=new ArrayList<>();
        prestations = daoPrestation.findAll();
        return prestations;
    }

    @Override
    public void annulerPrestation(int id) {
        Prestation prestation = daoPrestation.findById(id);
        prestation.setUnarchived(Boolean.FALSE);
          int nbr = daoRdv.update(prestation);
    }

    @Override
    public void showDetailsPrestation(int id) {
        Prestation pres = daoPrestation.findById(id);
        String libellep = pres.getLibellep();
        Consultation consultation = pres.getConsultation();
        ResponsablePrestation rep = pres.getResponsable();
        Date date = pres.getDate();
        boolean unarchived = pres.getUnarchived();
        Patient patient = pres.getPatient();
    }

    @Override
    public void filtrerByDate() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}