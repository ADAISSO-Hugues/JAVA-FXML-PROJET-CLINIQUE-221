/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entities.Consultation;
import entities.Patient;
import entities.Prestation;
import entities.Rdv;
import entities.User;
import java.util.List;

/**
 *
 * @author hp
 */
public interface IService {
       public User login(String login, String password);
       
       // use case Medecin
       public Rdv doRendezVous();
       public List<Rdv> showAllRendezVousByMedecin(int id);
       public List<Rdv> showAllRendezVousDoByPatient(int id);//(1) selecter le patient
       public List<Patient> showAllPatient();
       public void showDetailsOneConsultation(int id);
       public List<Consultation> showAllConsultationByMedecin(int id);
       public void AnnulerConsultation(int id);
       //deja fait use patient 28/10/2021
       //use case Patient
       public void addCompte(Patient patient);
       public Rdv askRendezVous();
      // public List<Rdv> showAllRendezVousDoByPatient();
       public List<Consultation> showAllConsultationByPatient(int id);//(1)
       public List<Prestation> showAllPrestationByPatient(int id);//(1)
       public List<Rdv> showAllRendezVous(int id);
       //deja fait use secretaire 30/10/2021 
       // use case Secretaire
       public List<Rdv> showAllRendezVous();
       public void valideRdv(int id, int idInsert,String type);
       public void annulerRendezVous(int id);
       
       
       // A faire use case Responsable Prestation
        public List<Prestation> showAllPrestation();
        public void annulerPrestation(int id);
        public void showDetailsPrestation(int id);
       
       
       // Responsable & Medecin 
        public void filtrerByDate();
         
        
}
