/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views.Patient;

import dao.RdvDao;
import entities.Patient;
import entities.Rdv;
import java.io.IOException;
import java.net.URL;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import views.ConnexionController;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class DoRdvPatientController implements Initializable {
    @FXML
    private Button use;
    @FXML
    private Button info;
    @FXML
    private Button out;
    @FXML
    private Button home;
    @FXML
    private TextField txtlibelle;
    @FXML
    private DatePicker txtdate;
    @FXML
    private ComboBox<String> cbotype;
    @FXML
    private Button button;
    @FXML
    private Text txtError;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        cbotype.getItems().add("PRESTATION");        
        cbotype.getItems().add("CONSULTATION");
        txtlibelle.setVisible(false);
        txtlibelle.setDisable(true);
        txtdate.setVisible(false);
        txtdate.setDisable(true);
        button.setVisible(false);
        button.setDisable(true);
    }    

    @FXML
    private void handleuse(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Patient/FonctionnalitePatient.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handleinfo(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Patient/InfoPatient.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handleout(ActionEvent event) throws IOException {
      this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/connexion.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handlehome(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Patient/patient.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }
    

    @FXML
    private void handleRdv(ActionEvent event) throws IOException {
        RdvDao r= new RdvDao();
        String libelle = txtlibelle.getText().trim();
        LocalDate d  = txtdate.getValue();
        Date date= java.sql.Date.valueOf(d);
        String type = cbotype.getSelectionModel().getSelectedItem();
        if("PRESTATION".equals(type)){
            if(libelle.isEmpty()){
                 txtError.setText("champ incorrect");
                 txtError.setVisible(true);
            }else{
               Patient patient =ConnexionController.getCtrl().getPatient();
                Rdv rdv = new Rdv(date , "TYPE_PRESTATION" , libelle , false , patient);
                r.insert(rdv);
                Alert alert =new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("demande rendez vous ");
                alert.setContentText("rendez vous  enregistee avec succes");
                alert.show();
            }
        }if("CONSULTATION".equals(type)){
            Patient patient =ConnexionController.getCtrl().getPatient();
                Rdv rdv = new Rdv(date , "TYPE_CONSULTATION" , "" , false , patient);
                r.insert(rdv);
                Alert alert =new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("demande rendez vous ");
                alert.setContentText("rendez vous  enregistee avec succes");
                alert.show();
        }
      /*  txtlibelle.setVisible(false);
        txtlibelle.setDisable(true);
        txtdate.setVisible(false);
        txtdate.setDisable(true);
        button.setVisible(false);
        button.setDisable(true);
        cbotype.setDisable(false);
      */
      this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Patient/FonctionnalitePatient.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handletype(ActionEvent event) {
         String type = cbotype.getSelectionModel().getSelectedItem();
         
        if("PRESTATION".equals(type)){
            txtlibelle.setVisible(true);
            txtlibelle.setDisable(false);
            txtdate.setVisible(true);
            txtdate.setDisable(false);
            button.setVisible(true);
            button.setDisable(false);
            cbotype.setDisable(true);
        }
        if("CONSULTATION".equals(type)){
            txtdate.setVisible(true);
            txtdate.setDisable(false);
            button.setVisible(true);
            button.setDisable(false);
            cbotype.setDisable(true);
        }
    }
    
}
