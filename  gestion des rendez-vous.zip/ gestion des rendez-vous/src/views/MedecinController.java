/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class MedecinController implements Initializable {

    @FXML
    private Text txtprofil;
    @FXML
    private Button use;
    @FXML
    private Button info;
    @FXML
    private Button out;
    @FXML
    private Button home;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        String role =ConnexionController.getCtrl().getUser().getRole();
        String nom =ConnexionController.getCtrl().getUser().getNomComplet();

        if("ROLE_MEDECIN".equals(role.trim())){
            role = "Medecin" ;
        }
        txtprofil.setText("Dans votre espace de travail \n\t\t"+ nom +" ");
    }    
    public void handleDrag(ActionEvent event){
        
    }

    @FXML
    private void handleuse(ActionEvent event) {
    }

    @FXML
    private void handleinfo(ActionEvent event) {
        
    }

    @FXML
    private void handleout(ActionEvent event) {
    }

    @FXML
    private void handlehome(ActionEvent event) {
    }
    
}
