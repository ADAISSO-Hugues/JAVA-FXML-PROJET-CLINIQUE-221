/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views.Secretaire;

import views.Patient.*;
import dao.PatientDao;
import entities.Antecedent;
import entities.Patient;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import services.Service;
import views.ConnexionController;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class InfoSecretaireController implements Initializable {
private Service service = new Service();
    @FXML
    private Button use;
    @FXML
    private Button info;
    @FXML
    private Button out;
    @FXML
    private Button home;
    @FXML
    private Text TXTNOM;
    @FXML
    private Text TXTLOGIN;
    @FXML
    private Text TXTPASSWORD;
    @FXML
    private Text txtpassword;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
                
        String nom =ConnexionController.getCtrl().getUser().getNomComplet();
        TXTNOM.setText("NOM : "+ nom);
        String login =ConnexionController.getCtrl().getUser().getLogin();
        TXTLOGIN.setText("LOGIN : "+ login);
       String password = ConnexionController.getCtrl().getUser().getPassword();
       txtpassword.setText(password);
       txtpassword.setVisible(false);
         
    }     
  /*  public void loadComboBox(int id) throws SQLException{
            if(!service.listAnten(id).isEmpty()){
            ob = FXCollections.observableArrayList(service.listAnten(id)) ;
            TXTANTECEDENT.setItems(ob);
            }else{
                Antecedent antecedent = new Antecedent() ;
                antecedent.setLibelleA("pas d'antecedent");
                TXTANTECEDENT.setValue(antecedent);
            }
    } 
*/
    @FXML
    private void handleuse(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Secretaire/FonctionnaliteSecretaire.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handleinfo(ActionEvent event) {
        
    }

    @FXML
    private void handleout(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/connexion.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handlehome(ActionEvent event) throws IOException {
        this.use.getScene().getWindow().hide();
        AnchorPane root = null;
        root = FXMLLoader.load(getClass().getResource("/views/Secretaire/secretaire.fxml"));
         Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handlepassword(ActionEvent event) {
        txtpassword.setVisible(true);
    }
    
}
