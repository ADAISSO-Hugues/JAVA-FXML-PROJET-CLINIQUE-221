/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import entities.Patient;
import entities.User;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import services.Service;

/**
 * FXML Controller class
 *
 * @author junio
 */
public class ConnexionController implements Initializable {

    @FXML
    private Text txtError;
    @FXML
    private TextField txtlLogin;
    @FXML
    private TextField txtpPassword;
    
    private final Service service = new Service();
    
    private static ConnexionController ctrl;
    
    private User user;
    private Patient patient;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         txtError.setVisible(false);
         ctrl = this;
    }    
    @FXML
    private void HandleConnexion(ActionEvent event) {
        String login = txtlLogin.getText().trim();
        String password = txtpPassword.getText().trim();
        if(login.isEmpty() || password.isEmpty())
        {
          txtError.setText("login ou le mot de passe Obligatoire");
          txtError.setVisible(true);
        }
        else{
          user = service.login(login, password);
          patient = service.getDaoPatient().findById(user.getId());
          if(user == null)
          {
               txtError.setText("login ou le mot de passe Incorrect");
               txtError.setVisible(true);
          }
          else
          {
              //Cache la fénétre de connexion
              this.txtError.getScene().getWindow().hide();
              AnchorPane root = null;
             
              try {
                   if ("ROLE_MEDECIN".equals(user.getRole())){
                  root = FXMLLoader.load(getClass().getResource("/views/medecin.fxml"));
                   }
                    if ("ROLE_PATIENT".equals(user.getRole())){
                        System.out.println(user.getId());
                  root = FXMLLoader.load(getClass().getResource("/views/Patient/patient.fxml"));
                   }
                     if ("ROLE_SECRETAIRE".equals(user.getRole())){
                  root = FXMLLoader.load(getClass().getResource("/views/Secretaire/secretaire.fxml"));
                   }
                      if ("ROLE_RESPONSABLE".equals(user.getRole())){
                  root = FXMLLoader.load(getClass().getResource("/views/responsable.fxml"));
                   }
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
                   
              } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
              }
            
          }
        }
    }

    public static ConnexionController getCtrl() {
        return ctrl;
    }

    public User getUser() {
        return user;
    }

    public Patient getPatient() {
        return patient;
    }

    
    
    
    @FXML
    public void HandleCompte(ActionEvent event){
     this.txtError.getScene().getWindow().hide();
     AnchorPane root = null;
              try {       
                  root = FXMLLoader.load(getClass().getResource("/views/views.Patient/CreerCompte.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
                   
              } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
              }
    }
}
