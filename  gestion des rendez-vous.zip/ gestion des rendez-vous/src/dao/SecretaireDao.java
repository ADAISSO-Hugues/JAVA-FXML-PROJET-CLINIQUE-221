/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Secretaire;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hp
 */
public class SecretaireDao implements IDao<Secretaire>{
     private final DataBase dataBase = new DataBase();

    private final String SQL_INSERT = "INSERT INTO `user` "
            + " ( `login`,`password`,`nom_complet`, `role`) "
            + " VALUES (?,?, ?, 'ROLE_SECRETAIRE',  ? )";
    private final String SQL_ALL=" SELECT * FROM `user`";
     private final String SQL_BY_ID="SELECT * FROM `user` WHERE role like 'ROLE_SECRETAIRE' and id=?";
    @Override
    public int insert(Secretaire secretaire) {
       int id = 0;
        try {
            dataBase.openConnexion();
            dataBase.initPrepareStatement(SQL_INSERT);
             dataBase.getPs().setString(2, secretaire.getPassword());
            dataBase.getPs().setString(3, secretaire.getNomComplet());
            dataBase.getPs().setString(1, secretaire.getLogin());
            
            dataBase.executeUpdate(SQL_INSERT);
            ResultSet rs =dataBase.getPs().getGeneratedKeys();
            if(rs.next())
            {
                id = rs.getInt(1);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(SecretaireDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            dataBase.closeConnexion();   
        } 
        return id;
    }

    @Override
    public int update(Secretaire ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Secretaire> findAll() {
          List<Secretaire> secretaires = new ArrayList(); 
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL);
        try {
            ResultSet rs = dataBase.executeSelect(SQL_ALL);
            
            while(rs.next())
            {
                Secretaire secr = new Secretaire();
                secr.setId(rs.getInt("id"));
                secr.setNomComplet(rs.getString("nom_complet"));
                secr.setLogin(rs.getString("login"));
                secr.setLogin(rs.getString("password"));
               
               secretaires.add(secr);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(SecretaireDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        
        return secretaires;
    }

    @Override
    public Secretaire findById(int id) {
       Secretaire pt=null;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_BY_ID);
         try {
             dataBase.getPs().setInt(1, id);
         } catch (SQLException ex) {
             Logger.getLogger(SecretaireDao.class.getName()).log(Level.SEVERE, null, ex);
         }
            ResultSet rs =dataBase.executeSelect(SQL_BY_ID);
        
            try {
               pt = new Secretaire();
                pt.setId(rs.getInt("id"));
                pt.setNomComplet(rs.getString("nom_complet"));
                pt.setLogin(rs.getString("login"));
                pt.setLogin(rs.getString("password"));
                
            } catch (SQLException ex) {
                Logger.getLogger(SecretaireDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        dataBase.closeConnexion();
        return pt;
    }
    
}
