/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Antecedent;
import entities.Constante;
import entities.Consultation;
import entities.Medecin;
import entities.Patient;
import entities.Prestation;
import entities.ResponsablePrestation;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hp
 */
public class PrestationDao implements IDao<Prestation> {
private final DataBase dataBase = new DataBase();
    private final String SQL_INSERT = "INSERT INTO `prestation` "
            + " ( `libellep`,`id_consultation` , `id_responsable`) "
            + " VALUES ( ?,?,?)";
    private final String SQL_ALL=" SELECT * FROM `prestation`";
    private final String SQL_BY_ID="SELECT * FROM `prestation` WHERE id=?";
    private final String SQL_UPDATE="UPDATE `rdv` SET `unarchived`=? WHERE `id`= ?";
    private final String SQL_ALL_ID=" SELECT * FROM `rdv` WHERE id_patient=?";
    private  ConsultationDao cons;
    private  ResponsablePrestationDao res;
    @Override
    public int insert(Prestation prestation) {
       int id = 0;
        try {
            dataBase.openConnexion();
            dataBase.initPrepareStatement(SQL_INSERT);
            dataBase.getPs().setString(1, prestation.getLibellep() );
             dataBase.getPs().setInt(2, prestation.getConsultation().getId());
              dataBase.getPs().setInt(3, prestation.getResponsable().getId());
            
            dataBase.executeUpdate(SQL_INSERT);
            ResultSet rs = dataBase.getPs().getGeneratedKeys();
            if(rs.next())
            {
                id = rs.getInt(1);   
            }
        } catch (SQLException ex) {
            Logger.getLogger(PrestationDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            dataBase.closeConnexion();   
        }
        return id;
    }

    @Override
    public int update(Prestation prestation) {
       int nbrLigne=0;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_UPDATE);
        try {
            dataBase.getPs().setBoolean(1, prestation.getUnarchived());
            dataBase.getPs().setInt(2, prestation.getId());
            nbrLigne=dataBase.executeUpdate(SQL_UPDATE);         
        } catch (SQLException ex) {
            Logger.getLogger(PrestationDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        dataBase.closeConnexion();
        return nbrLigne;
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Prestation> findAll() {
         List<Prestation> prestations=new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL);
       
            ResultSet rs =dataBase.executeSelect(SQL_ALL);
        
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    Prestation pt =new Prestation();
                    pt.setId(rs.getInt("id"));
                pt.setDate(rs.getDate("date"));
                pt.setUnarchived(rs.getBoolean("unarchived"));
                Consultation consultation = cons.findById(rs.getInt("id_medecin"));
                ResponsablePrestation responsable = res.findById(rs.getInt("id_patient"));
                pt.setConsultation(consultation);
                pt.setResponsable(responsable);
                    
                    prestations.add(pt);
                } catch (SQLException ex) {
                    Logger.getLogger(PrestationDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(PrestationDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return prestations;
    }
    public List<Prestation> findAllById(int id) throws SQLException {
         List<Prestation> prestations=new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_ID);
       dataBase.getPs().setInt(1, id);
            ResultSet rs =dataBase.executeSelect(SQL_ALL_ID);
        
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    Prestation pt =new Prestation();
                    pt.setId(rs.getInt("id"));
                pt.setDate(rs.getDate("date"));
                pt.setUnarchived(rs.getBoolean("unarchived"));
                Consultation consultation = cons.findById(rs.getInt("id_medecin"));
                ResponsablePrestation responsable = res.findById(rs.getInt("id_patient"));
                pt.setConsultation(consultation);
                pt.setResponsable(responsable);
                    
                    prestations.add(pt);
                } catch (SQLException ex) {
                    Logger.getLogger(PrestationDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(PrestationDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return prestations;
    }

    @Override
    public Prestation findById(int id) {
        Prestation pt=null;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_BY_ID);
       
            ResultSet rs =dataBase.executeSelect(SQL_BY_ID);
        
            try {
                //Mapping relation vers objet
               pt =new Prestation();
                    pt.setId(rs.getInt("id"));
                pt.setDate(rs.getDate("date"));
                pt.setUnarchived(rs.getBoolean("unarchived"));
                Consultation consultation = cons.findById(rs.getInt("id_medecin"));
                ResponsablePrestation responsable = res.findById(rs.getInt("id_patient"));
                pt.setConsultation(consultation);
                pt.setResponsable(responsable);
                
            } catch (SQLException ex) {
                Logger.getLogger(PrestationDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        dataBase.closeConnexion();
        return pt;
    }   
}
