/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Constante;
import entities.Consultation;
import entities.Medecin;
import entities.Ordonnance;
import entities.Patient;
import entities.Prestation;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hp
 */
public class ConsultationDao implements IDao<Consultation>{
 private final String SQL_INSERT = "INSERT INTO `rdv` "
            + " ( `type` , `date` ,` unarchived` , `id_patient` , `id_medecin`,`id_constante`,`id_prestation`,`id_ordonnance`) "
            + " VALUES ('TYPE_CONSULTATION',?,?,?,?,?,?,?)";
    private final String SQL_ALL=" SELECT * FROM `rdv`";
    private final String SQL_ALL_ID_MEDECIN=" SELECT * FROM `rdv` WHERE id_medecin=?";
     private final String SQL_ALL_ID_PATIENT=" SELECT * FROM `rdv` WHERE id_patient=?";
     private final String SQL_BY_ID="SELECT * FROM `rdv` WHERE id=?";
     private final String SQL_UPDATE="UPDATE `rdv` SET `unarchived`=? WHERE `id`= ?";
     
    private DataBase dataBase = new DataBase();
    private  MedecinDao med;
    private  PatientDao pat;
    private  PrestationDao pres;
    private  ConstanteDao cons;
    private  OrdonnanceDao ord;
    
    @Override
    public int insert(Consultation consultation) {
         int id = 0;
        try {
            dataBase.openConnexion();
            dataBase.initPrepareStatement(SQL_INSERT);
            dataBase.getPs().setDate(2, (Date) consultation.getDate());
            dataBase.getPs().setBoolean(3, consultation.getUnarchived());
            dataBase.getPs().setInt(4, consultation.getPatient().getId());
            dataBase.getPs().setInt(5, consultation.getMedecin().getId());
            dataBase.getPs().setInt(6, consultation.getConstante().getId());
            dataBase.getPs().setInt(7, consultation.getPrestation().getId());
            dataBase.getPs().setInt(8, consultation.getOrdonnance().getId());
            
            
            dataBase.executeUpdate(SQL_INSERT);
            ResultSet rs =dataBase.getPs().getGeneratedKeys();
            if(rs.next())
            {
                id = rs.getInt(1);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ConsultationDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            dataBase.closeConnexion();   
        } 
        return id;
    }

    @Override
    public int update(Consultation consultation) {
        int nbrLigne=0;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_UPDATE);
        try {
            dataBase.getPs().setBoolean(1, consultation.getUnarchived());
            dataBase.getPs().setInt(2, consultation.getId());
            nbrLigne=dataBase.executeUpdate(SQL_UPDATE);         
        } catch (SQLException ex) {
            Logger.getLogger(ConsultationDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        dataBase.closeConnexion();
        return nbrLigne;
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Consultation> findAll() {
        List<Consultation> consultations = new ArrayList(); 
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL);
        try {
            ResultSet rs = dataBase.executeSelect(SQL_ALL);
            
            while(rs.next())
            {
                Consultation pt = new Consultation();
                pt.setId(rs.getInt("id"));
                pt.setDate(rs.getDate("date"));
                pt.setUnarchived(rs.getBoolean("unarchived"));
                Medecin medecin = med.findById(rs.getInt("id_medecin"));
                Patient patient = pat.findById(rs.getInt("id_patient"));
                Constante constante = cons.findById(rs.getInt("id_constante"));
                Prestation prestation = pres.findById(rs.getInt("id_prestation"));
                Ordonnance ordonnance = ord.findById(rs.getInt("id_ordonnance"));
            //List<Constante> constantes = (ArrayList) rs.getObject("constantes") ;
                pt.setMedecin(medecin);
                pt.setPatient(patient);
               // pt.setConstantes(constantes);
               pt.setConstante(constante);
               pt.setPrestation(prestation);
               pt.setOrdonnance(ordonnance);
                
               
              consultations.add(pt);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ConsultationDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        
        return consultations;
    }
public List<Consultation> findAllById_Medecin(int id) throws SQLException {
        List<Consultation> consultations = new ArrayList(); 
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_ID_MEDECIN);
        dataBase.getPs().setInt(1, id);
        try {
            ResultSet rs = dataBase.executeSelect(SQL_ALL_ID_MEDECIN);
            
            while(rs.next())
            {
                Consultation pt = new Consultation();
                pt.setId(rs.getInt("id"));
                pt.setDate(rs.getDate("date"));
                pt.setUnarchived(rs.getBoolean("unarchived"));
                Medecin medecin = med.findById(rs.getInt("id_medecin"));
                Patient patient = pat.findById(rs.getInt("id_patient"));
                Constante constante = cons.findById(rs.getInt("id_constante"));
                Prestation prestation = pres.findById(rs.getInt("id_prestation"));
                Ordonnance ordonnance = ord.findById(rs.getInt("id_ordonnance"));
            //List<Constante> constantes = (ArrayList) rs.getObject("constantes") ;
                pt.setMedecin(medecin);
                pt.setPatient(patient);
               // pt.setConstantes(constantes);
               pt.setConstante(constante);
               pt.setPrestation(prestation);
               pt.setOrdonnance(ordonnance);
                
               
              consultations.add(pt);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ConsultationDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        
        return consultations;
    }
public List<Consultation> findAllById_Patient(int id) throws SQLException {
        List<Consultation> consultations = new ArrayList(); 
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_ID_PATIENT);
        dataBase.getPs().setInt(1, id);
        try {
            ResultSet rs = dataBase.executeSelect(SQL_ALL_ID_PATIENT);
            
            while(rs.next())
            {
                Consultation pt = new Consultation();
                pt.setId(rs.getInt("id"));
                pt.setDate(rs.getDate("date"));
                pt.setUnarchived(rs.getBoolean("unarchived"));
                Medecin medecin = med.findById(rs.getInt("id_medecin"));
                Patient patient = pat.findById(rs.getInt("id_patient"));
                Constante constante = cons.findById(rs.getInt("id_constante"));
                Prestation prestation = pres.findById(rs.getInt("id_prestation"));
                Ordonnance ordonnance = ord.findById(rs.getInt("id_ordonnance"));
            //List<Constante> constantes = (ArrayList) rs.getObject("constantes") ;
                pt.setMedecin(medecin);
                pt.setPatient(patient);
               // pt.setConstantes(constantes);
               pt.setConstante(constante);
               pt.setPrestation(prestation);
               pt.setOrdonnance(ordonnance);
                
               
              consultations.add(pt);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ConsultationDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        
        return consultations;
    }
    @Override
    public Consultation findById(int id) {
        Consultation pt=null;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_BY_ID);
       
            ResultSet rs =dataBase.executeSelect(SQL_BY_ID);
        
            try {
             pt = new Consultation();
                pt.setId(rs.getInt("id"));
                pt.setDate(rs.getDate("date"));
                pt.setUnarchived(rs.getBoolean("unarchived"));
                Medecin medecin = med.findById(rs.getInt("id_medecin"));
                Patient patient = pat.findById(rs.getInt("id_patient"));
                 Constante constante = cons.findById(rs.getInt("id_constante"));
                  Prestation prestation = pres.findById(rs.getInt("id_prestation"));
                Ordonnance ordonnance = ord.findById(rs.getInt("id_ordonnance"));
               //List<Constante> constantes = (ArrayList) rs.getObject("constantes") ;
                pt.setMedecin(medecin);
                pt.setPatient(patient);
                pt.setConstante(constante);
                pt.setPrestation(prestation);
                pt.setOrdonnance(ordonnance);
                 
               // pt.setConstantes(constantes);
                
            } catch (SQLException ex) {
                Logger.getLogger(ConsultationDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        dataBase.closeConnexion();
        return pt;
    }
    
}
