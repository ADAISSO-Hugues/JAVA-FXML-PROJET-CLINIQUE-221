/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Antecedent;
import entities.Consultation;
import entities.Patient;
import entities.Rdv;
import entities.ResponsablePrestation;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hp
 */
public class RdvDao implements IDao<Rdv>{
    private final String  SQL_BY_ID = "SELECT * FROM `rdv` WHERE id = ?";
     private final String  SQL_ALL = "SELECT * FROM `rdv` ";
     private final String  SQL_ALL_ID_MEDECIN = "SELECT * FROM `rdv` WHERE id_medecin=?";
      private final String  SQL_ALL_ID_PATIENT = "SELECT * FROM `rdv` WHERE id_patient=?";
     private final String SQL_INSERT = "INSERT INTO `rdv` "
            + " ( `type` , `date` , `unarchived` ,`id_patient`) "
            + " VALUES (?,?,?,?)";
     private final String SQL_UPDATE="UPDATE `rdv` SET `unarchived`=? WHERE `id`= ?";

    private final DataBase dataBase= new DataBase();
    PatientDao pat ;
    @Override
    public int insert(Rdv rdv) {
            int id = 0;
            try {
                dataBase.openConnexion();
                dataBase.initPrepareStatement(SQL_INSERT);
                dataBase.getPs().setString(1, rdv.getType() );
                dataBase.getPs().setDate(2, (Date) rdv.getDate());
                dataBase.getPs().setBoolean(3, rdv.getUnarchived() );
                dataBase.getPs().setInt(4, rdv.getPatient().getId() );
                dataBase.executeUpdate(SQL_INSERT);
                ResultSet rs = dataBase.getPs().getGeneratedKeys();
                if(rs.next())
                {
                    id = rs.getInt(1);   
                }
            } catch (SQLException ex) {
                Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
                dataBase.closeConnexion();   
            }
            return id;
    }

    @Override
    public int update(Rdv rdv) {
         int nbrLigne=0;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_UPDATE);
        try {
            dataBase.getPs().setBoolean(1, rdv.getUnarchived());
            dataBase.getPs().setInt(2, rdv.getId());
            nbrLigne=dataBase.executeUpdate(SQL_UPDATE);         
        } catch (SQLException ex) {
            Logger.getLogger(PrestationDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        dataBase.closeConnexion();
        return nbrLigne;
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Rdv> findAll() {
        List<Rdv> rdvs=new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL);
       
            ResultSet rs =dataBase.executeSelect(SQL_ALL);
        
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    Patient patient = pat.findById(rs.getInt("id_patient"));
                    Rdv rd =new Rdv();
                     rd.setId(rs.getInt("id"));
                     rd.setDate(rs.getDate("date"));
                     rd.setUnarchived(rs.getBoolean("unarchived"));
                     rd.setPatient(patient);
                    rdvs.add(rd);
                } catch (SQLException ex) {
                    Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return rdvs;
    }
    public List<Rdv> findAllById_Medecin( int id) throws SQLException {
        List<Rdv> rdvs=new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_ID_MEDECIN);
       dataBase.getPs().setInt(1,id);
            ResultSet rs =dataBase.executeSelect(SQL_ALL_ID_MEDECIN);
        
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    Patient patient = pat.findById(rs.getInt("id_patient"));
                    Rdv rd =new Rdv();
                     rd.setId(rs.getInt("id"));
                     rd.setDate(rs.getDate("date"));
                     rd.setUnarchived(rs.getBoolean("unarchived"));
                     rd.setPatient(patient);
                    rdvs.add(rd);
                } catch (SQLException ex) {
                    Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return rdvs;
    }
    public List<Rdv> findAllById_Patient( int id) throws SQLException {
        List<Rdv> rdvs=new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL_ID_PATIENT);
       dataBase.getPs().setInt(1,id);
            ResultSet rs =dataBase.executeSelect(SQL_ALL_ID_PATIENT);
        
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    Patient patient = pat.findById(rs.getInt("id_patient"));
                    Rdv rd =new Rdv();
                     rd.setId(rs.getInt("id"));
                     rd.setDate(rs.getDate("date"));
                     rd.setUnarchived(rs.getBoolean("unarchived"));
                     rd.setPatient(patient);
                    rdvs.add(rd);
                } catch (SQLException ex) {
                    Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return rdvs;
    }

    @Override
    public Rdv findById(int id) {
        Rdv rdv=null;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_BY_ID);
       
            ResultSet rs =dataBase.executeSelect(SQL_BY_ID);
        
            try {
                //Mapping relation vers objet
                 Patient patient = pat.findById(rs.getInt("id_patient"));
                 rdv =new Rdv();
                     rdv.setId(rs.getInt("id"));
                     rdv.setDate(rs.getDate("date"));
                     rdv.setUnarchived(rs.getBoolean("unarchived"));
                     rdv.setPatient(patient);
                
            } catch (SQLException ex) {
                Logger.getLogger(RdvDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        dataBase.closeConnexion();
        return rdv;
    }
    
}
