/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Historique;
import entities.Prescription;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hp
 */
public class PrescriptionDao implements IDao<Prescription>{
private DataBase dataBase = new DataBase();
    private final String SQL_INSERT = "INSERT INTO `prescription` "
            + " ( `id_medicament`,`id_ordonnance`) "
            + " VALUES ( ?,?)";
    private final String SQL_ALL=" SELECT * FROM `prescription`";
    private final String SQL_BY_ID="SELECT * FROM `prescription` WHERE id_ordonnance=?";
    @Override
    public int insert(Prescription pres) {
         int id = 0;
            try {
                dataBase.openConnexion();
                dataBase.initPrepareStatement(SQL_INSERT);
                dataBase.getPs().setInt(1, pres.getId_medicament() );
                dataBase.getPs().setInt(2, pres.getId_ordonnance());
                dataBase.executeUpdate(SQL_INSERT);
                ResultSet rs = dataBase.getPs().getGeneratedKeys();
                if(rs.next())
                {
                    id = rs.getInt(1);   
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConConsDao.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
                dataBase.closeConnexion();   
            }
            return id;
    }

    @Override
    public int update(Prescription ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Prescription> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Prescription findById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public List<Prescription> findAllBy(int id) {
        List<Prescription> prescriptions= new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_BY_ID);
       
            ResultSet rs =dataBase.executeSelect(SQL_BY_ID);
         
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    Prescription pres=new Prescription(rs.getInt("id_medicament"),rs.getInt("id_ordonnance"));
                    prescriptions.add(pres);
                } catch (SQLException ex) {
                    Logger.getLogger(PrescriptionDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(PrescriptionDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return prescriptions;
          
    }
}
