/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Antecedent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hp
 */
public class AntecedentDao implements IDao<Antecedent> {
    
    private DataBase dataBase = new DataBase();
    private final String SQL_INSERT = "INSERT INTO `antecedent` "
            + " ( `libelleA`) "
            + " VALUES ( ?)";
    private final String SQL_ALL=" SELECT * FROM antecedent";
    private final String SQL_BY_ID="SELECT * FROM `antecedent` WHERE id=?";
    private final String SQL_BY_LIBELLE="SELECT * FROM antecedent WHERE libelleA=?";
    @Override
    public int insert(Antecedent antecedent) {
            int id = 0;
            try {
                dataBase.openConnexion();
                dataBase.initPrepareStatement(SQL_INSERT);
                dataBase.getPs().setString(1, antecedent.getLibelleA() );
                dataBase.executeUpdate(SQL_INSERT);
                ResultSet rs = dataBase.getPs().getGeneratedKeys();
                if(rs.next())
                {
                    id = rs.getInt(1);   
                }
            } catch (SQLException ex) {
                Logger.getLogger(AntecedentDao.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
                dataBase.closeConnexion();   
            }
            return id;
    }

    @Override
    public int update(Antecedent ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Antecedent> findAll() {
        List<Antecedent> antecedent=new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL);
       
            ResultSet rs =dataBase.executeSelect(SQL_ALL);
        
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    Antecedent ant =new Antecedent(rs.getInt("id"),rs.getString("libelleA"));
                    antecedent.add(ant);
                } catch (SQLException ex) {
                    Logger.getLogger(AntecedentDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(AntecedentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return antecedent;
    }

    @Override
    public Antecedent findById(int id) {
       Antecedent antecedent=null;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_BY_ID);
        try {
            dataBase.getPs().setInt(1,id);
        } catch (SQLException ex) {
            Logger.getLogger(AntecedentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
            ResultSet rs =dataBase.executeSelect(SQL_BY_ID);
        try {
            if(rs.next()){
                try {
                    //Mapping relation vers objet
                    antecedent=new Antecedent(rs.getInt("id"),rs.getString("libelleA"));
                  
                } catch (SQLException ex) {
                    Logger.getLogger(AntecedentDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(AntecedentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        dataBase.closeConnexion();
        return antecedent;
    }
    public Antecedent findByLibelle(String libelleA) throws SQLException {
       Antecedent antecedent=null;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_BY_LIBELLE);
        dataBase.getPs().setString(1, libelleA);
            ResultSet rs =dataBase.executeSelect(SQL_BY_LIBELLE);
            if(rs.next()){
       
            try {
                //Mapping relation vers objet
                antecedent=new Antecedent(rs.getInt("id"),rs.getString("libelleA"));
            } catch (SQLException ex) {
                Logger.getLogger(AntecedentDao.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
        dataBase.closeConnexion();
        return antecedent;
    }
    
}
