/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Consultation;
import entities.Medecin;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author hp
 */
public class MedecinDao implements IDao<Medecin> {

    private final String SQL_INSERT = "INSERT INTO `user` "
            + " ( `login`,`password`,`nom_complet`, `role`,`statut`,`disponible`) "
            + " VALUES (?,?, ?, 'ROLE_PATIENT',  ? ,?)";
    private final String SQL_ALL=" SELECT * FROM `user` WHERE role like 'ROLE_MEDECIN' and disponible =? ";
    private final String SQL_BY_ID="SELECT * FROM user  WHERE role like 'ROLE_MEDECIN' AND id like ?";
    private final DataBase dataBase = new DataBase();
    @Override
    public int insert(Medecin medecin) {
        int id = 0;
        try {
            dataBase.openConnexion();
            dataBase.initPrepareStatement(SQL_INSERT);
             dataBase.getPs().setString(2, medecin.getPassword());
            dataBase.getPs().setString(3, medecin.getNomComplet());
            dataBase.getPs().setString(4, medecin.getStatut());
            dataBase.getPs().setBoolean(5, medecin.getDisponible());
            dataBase.getPs().setString(1, medecin.getLogin());
            
            dataBase.executeUpdate(SQL_INSERT);
            ResultSet rs =dataBase.getPs().getGeneratedKeys();
            if(rs.next())
            {
                id = rs.getInt(1);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(MedecinDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            dataBase.closeConnexion();   
        } 
        return id;
    }

    @Override
    public int update(Medecin ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Medecin> findAll() {
          List<Medecin> medecins = new ArrayList(); 
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL);
        
        try {
            dataBase.getPs().setBoolean(1,true);
            ResultSet rs = dataBase.executeSelect(SQL_ALL);
            
            while(rs.next())
            {
                Medecin pt = new Medecin();
                pt.setId(rs.getInt("id"));
                pt.setNomComplet(rs.getString("nom_complet"));
                pt.setStatut(rs.getString("statut"));
                pt.setDisponible(rs.getBoolean("disponible"));
                pt.setLogin(rs.getString("login"));
                pt.setPassword(rs.getString("password"));
               
               medecins.add(pt);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(MedecinDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        
        return medecins;
    }

    @Override
    public Medecin findById(int id) {
        Medecin pt=null;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_BY_ID);
       
            
        
            try {
                dataBase.getPs().setInt(1, id);
                ResultSet rs =dataBase.executeSelect(SQL_BY_ID);
                if(rs.next()){
                    pt = new Medecin();
                    pt.setId(rs.getInt("id"));
                    pt.setNomComplet(rs.getString("nom_complet"));
                    pt.setStatut(rs.getString("statut"));
                    pt.setDisponible(rs.getBoolean("disponible"));
                    pt.setLogin(rs.getString("login"));
                    pt.setPassword(rs.getString("password"));
                }
                
            } catch (SQLException ex) {
                Logger.getLogger(MedecinDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        dataBase.closeConnexion();
        return pt;
    }
    
}
