/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Consultation;
import entities.Medicament;
import entities.Ordonnance;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hp
 */
public class OrdonnanceDao implements IDao<Ordonnance> {
 private DataBase dataBase = new DataBase();
 MedicamentDao med;
 ConsultationDao cons;
    private final String SQL_INSERT = "INSERT INTO `ordonnance` "
            + " ( `posologie`,`id_consulation`,`id_medicament`) "
            + " VALUES (?,?,?)";
    private final String SQL_ALL=" SELECT * FROM `ordonnance`";
    private final String SQL_BY_ID="SELECT * FROM `ordannance` WHERE id=?";
    @Override
    public int insert(Ordonnance ordonnance) {
        int id = 0;
        try {
            dataBase.openConnexion();
            dataBase.initPrepareStatement(SQL_INSERT);
            dataBase.getPs().setInt(1, ordonnance.getPosologie());
            dataBase.getPs().setInt(2, ordonnance.getConsultation().getId());
            dataBase.getPs().setInt(3, ordonnance.getMedicament().getId());
            dataBase.executeUpdate(SQL_INSERT);
            ResultSet rs = dataBase.getPs().getGeneratedKeys();
            if(rs.next())
            {
                id = rs.getInt(1);   
            }
        } catch (SQLException ex) {
            Logger.getLogger(OrdonnanceDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            dataBase.closeConnexion();   
        }
        return id;
    }
    @Override
    public int update(Ordonnance ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Ordonnance> findAll() {
        List<Ordonnance> ordonnances=new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL);
       
            ResultSet rs =dataBase.executeSelect(SQL_ALL);
        
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    Medicament medicament = med.findById(rs.getInt("id_medicament"));
                    Consultation consultation = cons.findById(rs.getInt("id_consultation"));
                    Ordonnance ord =new Ordonnance();
                    ord.setId(rs.getInt("id"));
                    ord.setPosologie(rs.getInt("posologie"));
                    ord.setConsultation(consultation);
                    ord.setMedicament(medicament);
                    ordonnances.add(ord);
                } catch (SQLException ex) {
                    Logger.getLogger(AntecedentDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(OrdonnanceDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return ordonnances;
    }

    @Override
    public Ordonnance findById(int id) {
        Ordonnance ordonnance=null;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_BY_ID);
       
            ResultSet rs =dataBase.executeSelect(SQL_BY_ID);
        
            try {
                //Mapping relation vers objet
                    Medicament medicament = med.findById(rs.getInt("id_medicament"));
                    Consultation consultation = cons.findById(rs.getInt("id_consultation"));
                    ordonnance=new Ordonnance();
                    ordonnance.setId(rs.getInt("id"));
                    ordonnance.setPosologie(rs.getInt("posologie"));
                    ordonnance.setConsultation(consultation);
                    ordonnance.setMedicament(medicament);
                
            } catch (SQLException ex) {
                Logger.getLogger(OrdonnanceDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        dataBase.closeConnexion();
        return ordonnance;
    }
    
}
