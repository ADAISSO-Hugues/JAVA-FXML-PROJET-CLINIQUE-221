/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Antecedent;
import entities.ConCons;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hp
 */
public class ConConsDao implements IDao<ConCons> {
private DataBase dataBase = new DataBase();
    private final String SQL_INSERT = "INSERT INTO `con&cons` "
            + " ( `id_consultation`,`id_constante') "
            + " VALUES ( ?,?)";
    private final String SQL_ALL=" SELECT * FROM `con&cons`";
    private final String SQL_BY_ID="SELECT * FROM `con&cons` WHERE id=?";
    @Override
    public int insert(ConCons con) {
         int id = 0;
            try {
                dataBase.openConnexion();
                dataBase.initPrepareStatement(SQL_INSERT);
                dataBase.getPs().setInt(1, con.getId_consultation() );
                dataBase.getPs().setInt(2, con.getId_constante());
                dataBase.executeUpdate(SQL_INSERT);
                ResultSet rs = dataBase.getPs().getGeneratedKeys();
                if(rs.next())
                {
                    id = rs.getInt(1);   
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConConsDao.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
                dataBase.closeConnexion();   
            }
            return id;
    }

    @Override
    public int update(ConCons ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<ConCons> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public List<ConCons> findAllBy(int id) {
        List<ConCons> cons= new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_BY_ID);
       
            ResultSet rs =dataBase.executeSelect(SQL_BY_ID);
         
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    ConCons c=new ConCons(rs.getInt("id_consultation"),rs.getInt("id_constante"));
                    cons.add(c);
                } catch (SQLException ex) {
                    Logger.getLogger(ConConsDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(ConConsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return cons;
          
    }

    @Override
    public ConCons findById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
