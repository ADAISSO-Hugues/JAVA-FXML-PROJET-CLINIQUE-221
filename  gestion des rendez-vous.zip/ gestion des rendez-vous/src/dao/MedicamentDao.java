/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Medicament;
import entities.Ordonnance;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hp
 */
public class MedicamentDao implements IDao<Medicament>{
private DataBase dataBase = new DataBase();
OrdonnanceDao ord;
    private final String SQL_INSERT = "INSERT INTO `medicament` "
            + " ( `id` , `nom`, `code`,`id_ordonnance`) "
            + " VALUES ( ?,?,?,?)";
    private final String SQL_ALL=" SELECT * FROM `medicament`";
    private final String SQL_BY_ID="SELECT * FROM `medicament` WHERE id=?";
    @Override
    public int insert(Medicament medicament) {
         int id = 0;
        try {
            dataBase.openConnexion();
            dataBase.initPrepareStatement(SQL_INSERT);
            dataBase.getPs().setInt(1, medicament.getId());
            dataBase.getPs().setString(2, medicament.getNom());
            dataBase.getPs().setString(3, medicament.getCode());
            dataBase.getPs().setInt(4, medicament.getOrdonnance().getId());
            dataBase.executeUpdate(SQL_INSERT);
            ResultSet rs = dataBase.getPs().getGeneratedKeys();
            if(rs.next())
            {
                id = rs.getInt(1);   
            }
        } catch (SQLException ex) {
            Logger.getLogger(MedicamentDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            dataBase.closeConnexion();   
        }
        return id;
    }

    @Override
    public int update(Medicament ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Medicament> findAll() {
         List<Medicament> medicament=new ArrayList<>();
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL);
       
            ResultSet rs =dataBase.executeSelect(SQL_ALL);
        
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    Ordonnance ordonnance = ord.findById(rs.getInt("id_ordonnance"));
                    Medicament med =new Medicament(rs.getInt("id"),rs.getString("nom"),rs.getString("code"));
                    med.setOrdonnance(ordonnance);
                    medicament.add(med);
                } catch (SQLException ex) {
                    Logger.getLogger(MedicamentDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(MedicamentDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        return medicament;
    }

    @Override
    public Medicament findById(int id) {
        Medicament medicament=null;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_BY_ID);
       
            ResultSet rs =dataBase.executeSelect(SQL_BY_ID);
        
            try {
                //Mapping relation vers objet
                Ordonnance ordonnance = ord.findById(rs.getInt("id_ordonnance"));
                medicament=new Medicament(rs.getInt("id"),rs.getString("nom"),rs.getString("code"));
                medicament.setOrdonnance(ordonnance);
            } catch (SQLException ex) {
                Logger.getLogger(AntecedentDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        dataBase.closeConnexion();
        return medicament;
    }
    
}
