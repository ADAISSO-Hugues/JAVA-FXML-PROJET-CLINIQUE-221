/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Antecedent;
import entities.Patient;
import entities.Rdv;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hp
 */
public class PatientDao implements IDao<Patient> {
    private final String SQL_INSERT = "INSERT INTO `user` "
            + " ( `login`,`password`,`nom_complet`, `role`,  `code`,`id_antecedent`,`id_rdv`) "
            + " VALUES (?,?, ?, 'ROLE_PATIENT',? ,?,?)";
    private final String SQL_INSERT1 = "INSERT INTO `user`"
            + " ( `login`,`password`,`nom_complet`, `role`,`code`,`id_antecedent`)"
            + " VALUES (?,?,?,'ROLE_PATIENT',? ,?)";
    private final String SQL_ALL=" SELECT * FROM `user`";
     private final String SQL_BY_ID="SELECT * FROM `user` WHERE id=?";
    private DataBase dataBase = new DataBase();
    AntecedentDao ant;
    RdvDao rd;
    
    @Override
    public int insert(Patient patient) {
        int id = 0;
        try {
            dataBase.openConnexion();
            dataBase.initPrepareStatement(SQL_INSERT);
             dataBase.getPs().setString(2, patient.getPassword());
            dataBase.getPs().setString(3, patient.getNomComplet());
            dataBase.getPs().setString(4, patient.getCode());
            dataBase.getPs().setString(1, patient.getLogin());
            dataBase.getPs().setInt(5, patient.getAntecedent().getId());
            dataBase.getPs().setInt(6, patient.getRdv().getId());
            
            dataBase.executeUpdate(SQL_INSERT);
            ResultSet rs =dataBase.getPs().getGeneratedKeys();
            if(rs.next())
            {
                id = rs.getInt(1);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(PatientDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            dataBase.closeConnexion();   
        } 
        return id;
    }
public int insert1(Patient patient) {
        int id = 0;
        try {
            dataBase.openConnexion();
            dataBase.initPrepareStatement(SQL_INSERT1);
             dataBase.getPs().setString(2, patient.getPassword());
            dataBase.getPs().setString(3, patient.getNomComplet());
            dataBase.getPs().setString(4, patient.getCode());
            dataBase.getPs().setString(1, patient.getLogin());
            dataBase.getPs().setInt(5, patient.getAntecedent().getId());
            dataBase.executeUpdate(SQL_INSERT1);
            ResultSet rs =dataBase.getPs().getGeneratedKeys();
            if(rs.next())
            {
                id = rs.getInt(1);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(PatientDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            dataBase.closeConnexion();   
        } 
        return id;
    }
    @Override
    public int update(Patient ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Patient> findAll() {
         List<Patient> patients = new ArrayList(); 
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_ALL);
        try {
            ResultSet rs = dataBase.executeSelect(SQL_ALL);
            
            while(rs.next())
            {
                Antecedent antecedent = ant.findById(rs.getInt("id_antecedent"));
                Rdv rdv = rd.findById(rs.getInt("id_rdv"));
                Patient pt = new Patient();
                pt.setId(rs.getInt("id"));
                pt.setNomComplet(rs.getString("nom_complet"));
                pt.setCode(rs.getString("code"));
                pt.setLogin(rs.getString("login"));
                pt.setLogin(rs.getString("password"));
                pt.setAntecedent(antecedent);
                pt.setRdv(rdv);
               
               patients.add(pt);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(PatientDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        dataBase.closeConnexion();
        
        return patients;
    }

    @Override
    public Patient findById(int id) {
        Patient pt=null;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_BY_ID);
       
            ResultSet rs =dataBase.executeSelect(SQL_BY_ID);
        
            try {
                Antecedent antecedent = ant.findById(rs.getInt("id_antecedent"));
                Rdv rdv = rd.findById(rs.getInt("id_rdv"));
               pt = new Patient();
                pt.setId(rs.getInt("id"));
                pt.setNomComplet(rs.getString("nom_complet"));
                pt.setCode(rs.getString("code"));
                pt.setLogin(rs.getString("login"));
                pt.setLogin(rs.getString("password"));
                pt.setAntecedent(antecedent);
                pt.setRdv(rdv);
                
            } catch (SQLException ex) {
                Logger.getLogger(PatientDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        dataBase.closeConnexion();
        return pt;
    }
    
}
