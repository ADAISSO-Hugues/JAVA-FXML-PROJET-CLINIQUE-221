/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import dao.AntecedentDao;
import dao.DataBase;
import entities.Antecedent;
import java.sql.SQLException;
import java.util.List;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author hp
 */
public class NewMain{


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
         DataBase data =new DataBase();
          AntecedentDao ant = new AntecedentDao();    
           Antecedent antecedent = ant.findById(1);
                     // System.out.println(antecedent.getId());
        //Ouverture de connexion
    }
    
}
